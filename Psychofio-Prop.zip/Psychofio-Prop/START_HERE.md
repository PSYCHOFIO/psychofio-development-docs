# START HERE — Psychofio-Prop v1.2.1

## 1. Gereksinimler / Requirements

- OneSync
- oxmysql
- Optional: QBCore or ESX

## 2. Kurulum / Installation

```cfg
ensure oxmysql
ensure Psychofio-Prop
```

Resource klasör adı `Psychofio-Prop` olarak kalmalıdır.

## 3. Veritabanı / Database

Otomatik tablo oluşturma varsayılan olarak açıktır:

```lua
Config.Database.AutoCreate = true
```

Manuel SQL:

```text
sql/psychofio_props.sql
```

## 4. Yetki / Permission

QBCore ve ESX grupları `config.lua` içinden değiştirilebilir. `auto` modu
çalışan framework'ü seçer. Standalone kullanımda bütün oyunculara erişim
verilecekse `Config.Permissions.Enabled = false` açıkça ayarlanmalıdır.

## 5. Özel sunucu ayarları / Private server settings

`server_config.lua` yalnızca sunucuda yüklenir. Discord webhook, güvenlik limitleri ve session ayarlarını burada tutun.

## 6. İlk test / First test

1. `/psyprop`
2. Bir prop seçip yerleştirin.
3. `/propselect`
4. `/proppos`
5. `/psyprop` menüsünden freeze durumunu açıp kapatın.
6. `/propdelete`

## 7. Entitlement hatası

Sunucu konsolunda `You lack the required entitlement` görünürse asseti satın alan Cfx.re hesabının sunucu lisans anahtarının sahibi olduğundan ve assetin doğru hesaba tanımlandığından emin olun.

Destek koşulları için `SUPPORT_POLICY.md` dosyasını okuyun.
