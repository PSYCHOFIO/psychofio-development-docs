# Menü boyutu ve konumu

`Config.Menu.Layout`, `/psyprop` penceresinin sunucu genelindeki varsayılan görünümünü belirler.

```lua
Layout = {
    Horizontal = 'left',
    Vertical = 'center',
    OffsetX = '1.4vw',
    OffsetY = '0px',
    Width = 'min(1040px, 61vw)',
    Height = 'min(780px, 92vh)',
    MinWidth = 720,
    MinHeight = 520,
    ViewportMargin = 12,
    Draggable = true,
    Resizable = true,
    RememberUserLayout = true
}
```

## Konum seçenekleri

- `Horizontal`: `left`, `center`, `right`
- `Vertical`: `top`, `center`, `bottom`
- `OffsetX` ve `OffsetY`: `px`, `vw`, `vh` veya `%` kullanılabilir.
- `Width` ve `Height`: CSS uzunluğu veya `min(...)` değeri olabilir.

Örnek sol alt:

```lua
Horizontal = 'left'
Vertical = 'bottom'
OffsetX = '24px'
OffsetY = '24px'
Width = '900px'
Height = '70vh'
```

Örnek sağ orta:

```lua
Horizontal = 'right'
Vertical = 'center'
OffsetX = '2vw'
OffsetY = '0px'
Width = '52vw'
Height = '84vh'
```

## Oyuncu tarafından ayarlama

`Draggable = true` olduğunda pencere üst bardaki boş alandan sürüklenebilir. Arama alanı ve düğmeler sürükleme başlatmaz.

`Resizable = true` olduğunda sağ alt köşedeki turuncu tutamaçla boyut değiştirilebilir.

`RememberUserLayout = true` olduğunda her oyuncunun son konumu ve boyutu NUI localStorage içinde tutulur. Üst sağdaki `↺` düğmesi bu kaydı silerek config varsayılanına döner.

Sunucuda herkesin aynı sabit yerleşimi kullanması için üç seçeneği de kapat:

```lua
Draggable = false
Resizable = false
RememberUserLayout = false
```

Yerleşim sistemi event tabanlıdır; menü kapalıyken ve kullanıcı sürükleme/boyutlandırma yapmıyorken frame döngüsü çalıştırmaz.
