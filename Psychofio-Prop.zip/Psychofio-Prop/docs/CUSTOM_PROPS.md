# Custom prop streaming

Addon prop dosyalarını resource içindeki `stream/` klasörüne koyabilirsin:

- `.ydr`: model
- `.ytd`: texture
- `.ytyp`: archetype tanımı

`stream/` klasörüne `.txt`, `.md`, `.json` veya başka dokümantasyon dosyaları koyma.
FiveM bu klasörde bulunan her dosyayı streaming varlığı olarak kaydetmeye çalışır ve
uygun olmayan dosyalarda `no streaming module` uyarısı üretir.

`.ytyp` dosyaları `fxmanifest.lua` içindeki `DLC_ITYP_REQUEST` tanımıyla yüklenir.
Dosyaları ekledikten sonra resource'u yeniden başlat ve model adını menüdeki
Custom Prop Kataloğu Yönetimi bölümünden ekle.

Custom model başka bir resource tarafından stream ediliyorsa dosyaları buraya
kopyalamak yerine ilgili resource'u `Psychofio-Prop`'tan önce başlat.
