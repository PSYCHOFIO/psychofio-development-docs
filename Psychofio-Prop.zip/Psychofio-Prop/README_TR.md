# Psychofio-Prop v1.2.1

FiveM sunucuları için GTA V ve custom model destekli, kalıcı ve hassas prop yönetim sistemi.

## Öne çıkan özellikler

- Aramalı ve kategorili modern NUI
- GTA V ve custom propları aynı katalogda gösterme
- Sürüklenebilir ve yeniden boyutlandırılabilir menü
- Menüden kalıcı custom katalog yönetimi
- 1-50 adet sıralı toplu prop yerleştirme
- Hassas konum, yaw, pitch ve roll kontrolleri
- Yere sabitleme
- Prop seçme, yeniden konumlandırma, silme ve toplu temizleme
- Seçili prop için kalıcı freeze açma/kapatma
- oxmysql kalıcılığı ve restart sonrası otomatik yükleme
- QBCore ve ESX framework yetkilendirmesi
- OneSync uyumluluğu
- Sunucu kontrollü yerleştirme/düzenleme oturumları
- Sunucu taraflı mesafe, model, transform ve izin doğrulaması
- İstek hız sınırlaması ve global prop limiti
- İsteğe bağlı sunucu taraflı Discord denetim logları
- FiveM Asset Escrow ve Tebex dağıtımına uygun yapı

## Gereksinimler

- Güncel FiveM FXServer
- OneSync
- oxmysql
- Yetkilendirme için QBCore veya ESX; standalone kullanımda
  `Config.Permissions.Enabled = false` açıkça ayarlanmalıdır.

## Kurulum

1. Resource klasör adını `Psychofio-Prop` olarak koruyun.
2. Klasörü sunucunuzun `resources` dizinine yerleştirin.
3. `server.cfg` içine aşağıdaki sırayı ekleyin:

```cfg
ensure oxmysql
ensure Psychofio-Prop
```

4. Sunucuyu tamamen yeniden başlatın.

`Config.Database.AutoCreate = true` olduğunda tablolar otomatik oluşturulur. Manuel kurulum için:

```text
sql/psychofio_props.sql
```

Oluşturulan tablolar:

- `psychofio_props`
- `psychofio_prop_catalog`

## Yapılandırma dosyaları

### `config.lua`

Client ve server tarafından kullanılan genel ayarlar:

- Menü yerleşimi
- Komut adları
- Framework izinleri
- Yerleştirme kontrolleri
- Prop davranışı
- Katalog seçenekleri

### `server_config.lua`

Yalnızca sunucuda yüklenen özel ayarlar:

- Editör session süresi
- Maksimum kalıcı prop sayısı
- Katalog dışı model engeli
- İşlem cooldown değerleri
- Discord webhook ve denetim logları

Webhook adresini hiçbir zaman `config.lua` veya client dosyalarına taşımayın.

## Yetkilendirme

`Config.Permissions.Framework = 'auto'`, çalışan QBCore veya ESX resource'unu
otomatik seçer. Framework grupları:

- QBCore: `admin`, `god`
- ESX: `admin`, `superadmin`

Standalone sunucuda bütün oyunculara erişim vermek için
`Config.Permissions.Enabled = false` değerini bilinçli olarak ayarlayın.

## Komutlar

| Komut | Açıklama |
|---|---|
| `/psyprop` | Prop kataloğunu açar. |
| `/propselect` | Nişangâhtaki yönetilen propu seçer. |
| `/proppos` | Seçili propu yeniden konumlandırır. |
| `/propdelete` | Seçili propu siler. |
| `/propclear confirm` | Tüm kalıcı propları temizler. |

Komut isimleri `config.lua` içindeki `Config.Commands` bölümünden değiştirilebilir.

## Prop freeze

`/propselect` ile kalıcı bir prop seçin ve `/psyprop` menüsünü açın. Sol
paneldeki `FREEZE AÇ / FREEZE KAPAT` düğmesi propun fizik durumunu değiştirir.
Durum SQL'de saklanır ve resource/server restartından sonra tekrar uygulanır.

## Yerleştirme kontrolleri

| Tuş | İşlem |
|---|---|
| Yön tuşları | Kamera yönüne göre yatay hareket |
| Q / E | Yukarı / aşağı |
| Numpad `*` | Yere sabitlemeyi aç / kapat |
| Mouse tekerleği | Yaw rotasyonu |
| Numpad 8 / 5 | Pitch yukarı / aşağı |
| Numpad 4 / 6 | Roll sol / sağ |
| Sol Shift | Hızlı hareket |
| Sol Ctrl | Hassas hareket |
| Enter / Numpad Enter | Kaydet |
| Backspace | İptal |

## Custom prop ekleme

Başka bir resource custom modeli stream ediyorsa o resource önce başlatılmalıdır:

```cfg
ensure custom-props
ensure Psychofio-Prop
```

Statik katalog kayıtları:

```text
shared/custom_props.lua
```

Model dosyalarını bu resource içinden stream etmek için `stream/` klasörünü kullanabilirsiniz.

`ServerConfig.Security.RequireCatalogModel = true` olduğunda, yerleştirilecek modelin GTA, statik custom veya veritabanı kataloğunda bulunması gerekir.

## Discord logları

`server_config.lua` içinde:

```lua
ServerConfig.Logging.Enabled = true
ServerConfig.Logging.Webhook = 'DISCORD_WEBHOOK'
```

Oluşturma, düzenleme, silme, toplu temizleme, katalog yönetimi ve güvenlik engelleri ayrı ayrı açılıp kapatılabilir.

## v1.2.0'dan yükseltme

- `frozen` sütunu başlangıçta otomatik eklenir. Veritabanı kullanıcısının
  `ALTER` izni yoksa `sql/upgrade_1_2_1.sql` dosyasını bir kez çalıştırın.
- Eski resource'un yedeğini alın.
- Yeni klasörle değiştirin.
- `server_config.lua` ayarlarını kontrol edin.
- Sunucuyu tamamen yeniden başlatın.

## Asset Escrow

Core `client/` ve `server/` Lua dosyaları korunmak üzere hazırlanmıştır. Config, katalog, SQL, dokümantasyon, NUI ve stream klasörü müşteri düzenlemeleri için açık bırakılmıştır.

Ayrıntılar:

- `START_HERE.md`
- `ASSET_ESCROW.md`
- `SUPPORT_POLICY.md`
- `CHANGELOG.md`
- `docs/CUSTOM_PROPS.md`
- `docs/MENU_LAYOUT.md`
