# Psychofio-Prop v1.2.1

A persistent and precise FiveM prop management system with GTA V and custom model support.

## Main features

- Modern searchable and categorized NUI
- GTA V and custom props in a single catalog
- Draggable and resizable menu
- Persistent custom catalog management from the UI
- Sequential batch placement from 1 to 50 props
- Precise position, yaw, pitch, and roll controls
- Ground lock
- Prop selection, repositioning, deletion, and full clearing
- Persistent freeze toggle for the selected prop
- oxmysql persistence with automatic loading after restart
- QBCore and ESX framework permissions
- OneSync support
- Server-controlled placement and edit sessions
- Server-side permission, distance, model, and transform validation
- Request throttling and a global persistent prop limit
- Optional server-only Discord audit logs
- FiveM Asset Escrow and Tebex-ready structure

## Requirements

- A current FiveM FXServer build
- OneSync
- oxmysql
- QBCore or ESX for authorization. Standalone servers must explicitly set
  `Config.Permissions.Enabled = false`.

## Installation

1. Keep the resource folder name as `Psychofio-Prop`.
2. Place it inside your server's `resources` directory.
3. Add the following start order to `server.cfg`:

```cfg
ensure oxmysql
ensure Psychofio-Prop
```

4. Fully restart the server.

When `Config.Database.AutoCreate = true`, the database tables are created automatically. For a manual installation, import:

```text
sql/psychofio_props.sql
```

Created tables:

- `psychofio_props`
- `psychofio_prop_catalog`

## Configuration files

### `config.lua`

Shared client/server settings:

- Menu layout
- Command names
- Framework permissions
- Placement controls
- Prop behavior
- Catalog options

### `server_config.lua`

Server-only private settings:

- Editor session lifetime
- Maximum persistent prop count
- Catalog-only model enforcement
- Action cooldowns
- Discord webhook and audit logs

Never move the webhook into `config.lua` or any client file.

## Permissions

`Config.Permissions.Framework = 'auto'` automatically selects the running
QBCore or ESX resource. Framework groups:

- QBCore: `admin`, `god`
- ESX: `admin`, `superadmin`

To allow all players on a standalone server, explicitly set
`Config.Permissions.Enabled = false`.

## Commands

| Command | Description |
|---|---|
| `/psyprop` | Opens the prop catalog. |
| `/propselect` | Selects the managed prop under the crosshair. |
| `/proppos` | Repositions the selected prop. |
| `/propdelete` | Deletes the selected prop. |
| `/propclear confirm` | Clears all persistent props. |

Command names can be changed under `Config.Commands` in `config.lua`.

## Prop freeze

Select a persistent prop with `/propselect`, then open `/psyprop`. Use the
`FREEZE ON / FREEZE OFF` control in the selected-prop panel. The state is
stored in SQL and applied again after a resource or server restart.

## Placement controls

| Key | Action |
|---|---|
| Arrow keys | Horizontal movement relative to the camera |
| Q / E | Move up / down |
| Numpad `*` | Toggle ground lock |
| Mouse wheel | Yaw rotation |
| Numpad 8 / 5 | Pitch up / down |
| Numpad 4 / 6 | Roll left / right |
| Left Shift | Fast movement |
| Left Ctrl | Precision movement |
| Enter / Numpad Enter | Save |
| Backspace | Cancel |

## Adding custom props

When another resource streams a custom model, start it before Psychofio-Prop:

```cfg
ensure custom-props
ensure Psychofio-Prop
```

Static catalog entries:

```text
shared/custom_props.lua
```

Use the `stream/` directory to stream models directly from this resource.

When `ServerConfig.Security.RequireCatalogModel = true`, the model must exist in the GTA, static custom, or database catalog before it can be placed.

## Discord logs

Inside `server_config.lua`:

```lua
ServerConfig.Logging.Enabled = true
ServerConfig.Logging.Webhook = 'DISCORD_WEBHOOK'
```

Create, update, delete, clear, catalog, and security events can be enabled independently.

## Upgrading from v1.2.0

- The `frozen` column is added automatically. If the database account cannot
  run `ALTER`, import `sql/upgrade_1_2_1.sql` once.
- Back up the previous resource.
- Replace it with the new folder.
- Review `server_config.lua`.
- Fully restart the server.

## Asset Escrow

Core Lua files under `client/` and `server/` are prepared for protection. Config, catalogs, SQL, documentation, NUI, and stream files remain open for customer customization.

See:

- `START_HERE.md`
- `ASSET_ESCROW.md`
- `SUPPORT_POLICY.md`
- `CHANGELOG.md`
- `docs/CUSTOM_PROPS.md`
- `docs/MENU_LAYOUT.md`
