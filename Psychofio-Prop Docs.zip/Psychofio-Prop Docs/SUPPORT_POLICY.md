# Support Policy — Psychofio-Prop

## Supported

- Installation using the documented resource name and start order
- Current FiveM FXServer builds with OneSync enabled
- Current oxmysql releases
- Default QBCore and ESX permission modes
- Reproducible errors in unmodified protected core files
- Configuration questions relating to documented options

## Not included

- Custom feature development
- Installation of unrelated frameworks or server packs
- Fixing conflicts caused by leaked, modified, or repackaged copies
- Support for deprecated artifacts or unsupported forks
- Debugging custom models whose stream files are invalid
- Database recovery after manual deletion or corruption
- Support for changes made inside protected core files

## Before requesting support

Provide:

1. Purchase transaction or Tebex/Cfx entitlement proof
2. FXServer artifact/build information
3. oxmysql version
4. Framework and version
5. Relevant F8/server-console error
6. Steps to reproduce
7. Your `config.lua` and `server_config.lua` with secrets removed

Never publish your Discord webhook, database password, server license key, or other secrets.

Support is provided through the channel listed on the official Tebex product page.
