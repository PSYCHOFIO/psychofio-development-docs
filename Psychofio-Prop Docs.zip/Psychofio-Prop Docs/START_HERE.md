# START HERE — Psychofio-Prop v1.2.1

## 1. Requirements

- FiveM OneSync
- `oxmysql`
- Optional: QBCore or ESX for framework authorization

## 2. Installation

Keep the resource folder name as `Psychofio-Prop` and use this start order:

```cfg
ensure oxmysql
ensure Psychofio-Prop
```

Perform a full server restart after installation.

## 3. Database

Automatic table creation is enabled by default:

```lua
Config.Database.AutoCreate = true
```

For a manual installation, import:

```text
sql/psychofio_props.sql
```

## 4. Permissions

QBCore and ESX groups can be changed in `config.lua`. The `auto` mode selects
the active framework. To allow every player on a standalone server, explicitly
set:

```lua
Config.Permissions.Enabled = false
```

## 5. Private server settings

`server_config.lua` is loaded only by the server. Keep the Discord webhook,
security limits, and editor-session settings in this file.

## 6. First acceptance test

1. Open the catalog with `/psyprop`.
2. Select and place a prop.
3. Select it with `/propselect`.
4. Reposition it with `/proppos`.
5. Open `/psyprop` and toggle the selected prop's freeze state.
6. Restart the resource and verify that the prop and freeze state are restored.
7. Delete it with `/propdelete`.

## 7. Entitlement errors

If the server console reports `You lack the required entitlement`, verify that
the server license key belongs to the Cfx.re account that owns the asset and
that the entitlement is assigned to the correct account.

Read `README_EN.md` for the complete guide and `SUPPORT_POLICY.md` for support
terms.
