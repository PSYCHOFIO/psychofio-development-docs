# Asset Escrow Notes

Psychofio-Prop is structured for Cfx.re Asset Escrow distribution.

## Protected core

The intended protected Lua files are:

```text
client/main.lua
client/selection.lua
client/placement.lua
server/security.lua
server/catalog.lua
server/main.lua
server/commands.lua
```

## Open customer files

The manifest intentionally ignores:

```text
config.lua
server_config.lua
shared/catalog.lua
shared/custom_props.lua
README files
documentation
SQL files
web/*
stream/*
```

NUI files remain readable because Cfx.re Asset Escrow does not encrypt NUI content. Do not place server secrets, license keys, database credentials, or Discord webhooks in NUI, shared, or client files.

## Distribution

The unencrypted upload ZIP is uploaded to Cfx.re Portal as a created asset. The Tebex package delivery type must be configured as `FiveM Asset` and linked to that created asset.

Do not add a second IP-lock, Discord-role check, remote code loader, or custom license-key API. The official Cfx.re entitlement system is the distribution and ownership control layer.

## Customer entitlement error

When an unauthorized server starts an escrowed resource, the server console may show:

```text
You lack the required entitlement
```

The customer should confirm that:

- The server license key belongs to the Cfx.re account that owns the asset.
- The resource was downloaded from the correct Cfx.re account.
- The resource folder was not renamed.
- The encrypted files were not modified or mixed with another build.
