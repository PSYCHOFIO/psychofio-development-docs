# Test Report — Psychofio-Prop v1.2.1

## Completed static checks

- Open v1.2.1 permission/freeze modules passed Lua 5.4 parser validation.
- Protected v1.2.0 core files retain their original escrow build.
- `web/app.js` passed Node.js syntax validation.
- All 43 literal NUI element bindings resolve to an HTML element.
- Server mock passed framework resolution, SQL state, atomic toggle and
  broadcast checks.
- Client mock passed NUI callbacks and freeze/unfreeze physics application.
- Every manifest-referenced script and required customer document exists.
- Client network events use a server-origin guard.
- Discord webhook configuration exists only in `server_config.lua`.
- No hard-coded webhook, database password, server key, remote loader, or custom license API was found.
- Asset Escrow ignore paths preserve customer-editable config, catalog, SQL, NUI, documentation, and stream files.
- Customer ZIP and Seller Kit ZIP passed archive integrity tests.

## Security scenarios reviewed

- Unauthorized permission checks
- Menu session expiry
- Forged create session
- Forged edit session
- Model not present in catalog
- Batch session model/quantity mismatch
- Request spam
- Global prop limit race
- Custom catalog limit race
- Create/update/delete conflict with global clear
- Player disconnect session cleanup
- Database insert/update/delete failure paths
- Framework-only permission preflight
- Persistent freeze migration, status, toggle, sync and reapply paths

## Live server tests still required

A FiveM/OneSync/oxmysql runtime is not available in this build environment. Before publishing, test:

1. QBCore permission mode
2. ESX permission mode
3. Explicit standalone access with permissions disabled
4. Single prop placement
5. 50-prop batch placement
6. Selection, freeze toggle and repositioning
7. Freeze persistence after resource/server restart
8. Delete and clear confirmation
9. Static custom prop
10. Database custom catalog add/delete
11. Missing entity respawn
12. Discord audit webhook
13. Cfx.re encrypted Asset Escrow build
14. Entitlement behavior on an authorized test server
