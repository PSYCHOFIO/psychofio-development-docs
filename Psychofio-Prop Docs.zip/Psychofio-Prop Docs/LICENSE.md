# Psychofio Development Commercial License

Copyright © 2026 Psychofio Development. All rights reserved.

By purchasing or downloading Psychofio-Prop through an authorized Tebex package, the purchaser receives a limited, non-exclusive, non-transferable license to use the resource on FiveM servers owned or controlled by the purchasing Cfx.re account, subject to the entitlement rules applied by Cfx.re Asset Escrow.

## Permitted

- Use the resource on servers owned or controlled by the purchasing account.
- Modify files intentionally left open through `escrow_ignore`.
- Create private backups for installation and disaster recovery.
- Configure the resource for the purchaser's own community.

## Not permitted

- Reselling, redistributing, leaking, sharing, sublicensing, or gifting the resource.
- Uploading the resource or protected code to public repositories, forums, file hosts, or other marketplaces.
- Attempting to decrypt, bypass, defeat, or interfere with Asset Escrow protections or entitlement checks.
- Repackaging the resource as part of another paid or free product without written permission.
- Claiming authorship or removing copyright and license notices.

## Dependencies and third-party services

FiveM, Cfx.re, Tebex, oxmysql, QBCore, ESX, Discord, and Grand Theft Auto V are third-party products or services governed by their own licenses and terms. This license grants no ownership or rights in those products.

## Warranty and liability

The resource is provided on an “as available” basis. Support and compatibility are limited to the conditions described in `SUPPORT_POLICY.md`. To the maximum extent allowed by applicable law, Psychofio Development is not liable for indirect loss, lost revenue, server downtime, data loss, or damage caused by third-party resources, modified files, unsupported server builds, or incorrect installation.

Mandatory consumer rights that cannot legally be excluded remain unaffected.

## Termination

The license terminates automatically if the purchaser redistributes the resource, bypasses entitlement controls, or materially violates these terms. Termination does not limit any other legal remedies available to the rights holder.
