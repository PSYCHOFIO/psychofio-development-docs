# Custom prop streaming

Place add-on prop files in the resource's `stream/` directory:

- `.ydr`: model
- `.ytd`: texture
- `.ytyp`: archetype definition

Do not place `.txt`, `.md`, `.json`, or other documentation files in
`stream/`. FiveM attempts to register every file in this directory as a
streaming asset and reports a `no streaming module` warning for unsupported
files.

`.ytyp` files are loaded through the `DLC_ITYP_REQUEST` declaration in
`fxmanifest.lua`. After adding the files, restart the resource and add the
model name through the Custom Prop Catalog Management section of the menu.

If another resource streams the custom model, do not duplicate its files.
Start that resource before `Psychofio-Prop`:

```cfg
ensure custom-props
ensure Psychofio-Prop
```

When `ServerConfig.Security.RequireCatalogModel = true`, the model must exist
in the GTA, static custom, or database catalog before it can be placed.
