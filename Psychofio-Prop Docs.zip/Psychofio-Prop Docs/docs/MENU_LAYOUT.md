# Menu size and position

`Config.Menu.Layout` defines the server-wide default layout of the `/psyprop`
window.

```lua
Layout = {
    Horizontal = 'left',
    Vertical = 'center',
    OffsetX = '1.4vw',
    OffsetY = '0px',
    Width = 'min(1040px, 61vw)',
    Height = 'min(780px, 92vh)',
    MinWidth = 720,
    MinHeight = 520,
    ViewportMargin = 12,
    Draggable = true,
    Resizable = true,
    RememberUserLayout = true
}
```

## Position options

- `Horizontal`: `left`, `center`, or `right`
- `Vertical`: `top`, `center`, or `bottom`
- `OffsetX` and `OffsetY`: accept `px`, `vw`, `vh`, or `%`
- `Width` and `Height`: accept a CSS length or a `min(...)` expression

Bottom-left example:

```lua
Horizontal = 'left'
Vertical = 'bottom'
OffsetX = '24px'
OffsetY = '24px'
Width = '900px'
Height = '70vh'
```

Right-center example:

```lua
Horizontal = 'right'
Vertical = 'center'
OffsetX = '2vw'
OffsetY = '0px'
Width = '52vw'
Height = '84vh'
```

## Player customization

When `Draggable = true`, players can drag the window from an empty area of the
top bar. Search fields and buttons do not begin a drag operation.

When `Resizable = true`, players can resize the window with the orange handle
in the bottom-right corner.

When `RememberUserLayout = true`, each player's latest position and size are
stored in NUI `localStorage`. The `↺` button in the top-right corner clears the
saved value and restores the configured default.

To force the same fixed layout for every player, disable all three options:

```lua
Draggable = false
Resizable = false
RememberUserLayout = false
```

The layout system is event-driven. It does not run a per-frame loop while the
menu is closed or while the player is not dragging or resizing it.
