# Security Configuration

Security settings are stored in `server_config.lua`.

## Session timeout

```lua
ServerConfig.Security.SessionTimeoutSeconds = 300
```

Placement sessions bind the selected model and requested batch amount. Edit sessions bind the selected persistent prop ID.

## Global prop limit

```lua
ServerConfig.Security.MaxPersistentProps = 5000
```

Set this value to `0` to disable the global limit.

## Catalog model enforcement

```lua
ServerConfig.Security.RequireCatalogModel = true
```

When enabled, a model must exist in one of these sources:

- `shared/catalog.lua`
- `shared/custom_props.lua`
- `psychofio_prop_catalog`

## Rate limits

Each value is a minimum delay in milliseconds. Extremely low values may increase database and network load.

## Discord logs

Keep the webhook only in `server_config.lua`. It is a server script and is not sent to clients.
