# Changelog

## v1.2.1 — Framework Permissions & Prop Freeze

### Added

- Selected-prop freeze on/off control in the management menu
- Persistent `frozen` SQL state and automatic schema migration
- Client synchronization and restart reapplication for freeze state
- Framework-only authorization preflight

### Changed

- Permission configuration now supports only QBCore and ESX
- Markdown documentation is distributed separately from the runtime archive

## v1.2.0 — Tebex & Security Release

### Added

- Server-controlled menu and edit sessions
- Session-bound batch placement
- Server-side catalog model enforcement
- Global persistent prop limit
- Race-safe persistent prop and custom catalog reservations
- Server-only Discord audit logging
- Client protection against locally forged server events
- Player disconnect cleanup for sessions and rate-limit state
- Asset Escrow manifest configuration
- Commercial license, support policy, startup guide, and escrow documentation

### Improved

- Request throttling for menu, sync, selection, edit, create, update, delete, clear, and catalog actions
- Server-side validation for prop creation and repositioning
- Database failure recovery paths
- Product naming and resource folder documentation
- Console startup information

### Fixed

- Incorrect `Psychofio-Development` folder name in the installation guide
- Custom catalog limit race condition
- Persistent prop limit race condition
- Public/shared configuration risk for Discord webhook values

### Compatibility

- No database migration is required from v1.1.0.
