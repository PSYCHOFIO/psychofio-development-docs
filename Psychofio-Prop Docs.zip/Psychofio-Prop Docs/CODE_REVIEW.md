# Code Review Summary — v1.2.1

## High-priority findings resolved

### 1. Client-trusted editor flow

The previous create and update events relied on permission and distance checks but did not require a server-issued editor session.

**Resolution:** menu and edit sessions are now issued by the server, expire automatically, and bind model/batch or prop ID.

### 2. Shared webhook risk

A Discord webhook must never be placed in a shared config because shared scripts are sent to clients.

**Resolution:** `server_config.lua` is a server-only editable file.

### 3. Prop and catalog limit races

Concurrent MySQL requests could pass a count check before either insert completed.

**Resolution:** protected in-memory reservations now account for pending inserts.

### 4. Clear-operation races

A global clear could overlap an active create, update, or delete operation.

**Resolution:** mutation tracking prevents clear and individual database mutations from overlapping.

### 5. Client-local forged server events

Another client resource could locally trigger registered client events.

**Resolution:** server-origin checks were added to client network handlers.

### 6. Installation naming mismatch

The previous documentation instructed customers to use `Psychofio-Development`, while the product archive is `Psychofio-Prop`.

**Resolution:** all installation and start-order documentation now uses `Psychofio-Prop`.

## Additional improvements

- Sync request throttling
- Player disconnect cleanup
- Global persistent prop cap
- Catalog-only model enforcement
- Discord audit logs
- Asset Escrow manifest preparation
- Commercial and support documentation
