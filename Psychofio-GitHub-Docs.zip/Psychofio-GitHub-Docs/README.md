# Psychofio Documentation

Bu depo, Psychofio resource belgelerini kod paketlerinden ayrı tutar.

## Belgeler

- `Psychofio-Appearance`: Kurulum, kullanım, sürüm notları, destek ve yasal
  bildirimler.
- `Psychofio-NPC`: Türkçe/İngilizce kurulum, animasyon entegrasyonu, sürüm
  notları, destek ve yasal bildirimler.

## Runtime paketleri

Runtime ZIP dosyaları Markdown belgesi içermez. Kurulumdan önce ilgili resource
klasöründeki `START_HERE.md` ve `README` belgesini bu depodan okuyun.

`LICENSE.md` ve `THIRD_PARTY_NOTICES.md` belgeleri dağıtım koşullarının bir
parçasıdır; silmeyin ve herkese açık tutun.
