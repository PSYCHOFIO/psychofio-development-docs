# START HERE — Psychofio-Appearance v1.4.3

Thank you for purchasing Psychofio-Appearance.

## Important entitlement information

This product uses **Cfx.re Asset Escrow**. Your purchase is linked to the Cfx.re account used during checkout. The FiveM server license key running this resource must belong to, or be correctly associated with, the same entitled Cfx.re account.

There is no separate Psychofio IP key, Discord key, or manual serial number.

If the console shows `You lack the required entitlement`, verify the purchasing Cfx.re account and the account that owns the server license key before opening a support ticket.

## Installation summary

1. Keep the resource folder name exactly `Psychofio-Appearance`.
2. Place it under `resources/[local]/`.
3. Ensure OneSync is enabled.
4. Start dependencies before this resource:

```cfg
ensure oxmysql
ensure qb-core
# When using the default QBCore character flow:
ensure qb-multicharacter
ensure Psychofio-Appearance
```

If your server uses `qb-target`, start it before this resource. Start any custom
clothing stream resources before this resource as well.

5. Tables and safe schema upgrades are created automatically. Use
   `sql/psychofio_appearance.sql` only as a manual fallback; the 1.2.x upgrade
   script is intended for an explicit legacy migration.
6. Review `shared/config.lua`, `shared/locales.lua`, `shared/tattoos.lua`, and `permissions.cfg`.
7. Restart the server and complete the acceptance checks in `INSTALL.md`.

Detailed instructions are in `INSTALL.md` and `README.md`.

## Editable files

The following files are intentionally excluded from escrow and may be edited:

- `shared/config.lua`
- `shared/locales.lua`
- `shared/tattoos.lua`
- `permissions.cfg`
- `sql/*.sql`
- Documentation and license files

Core Lua files are protected by Cfx.re Asset Escrow. Web/NUI source is delivered to clients by FiveM and must not be redistributed.

## Before requesting support

Read `SUPPORT_POLICY.md` and include the required diagnostic information. Never post your Tebex secret, server license key, database password, or Discord webhook publicly.
