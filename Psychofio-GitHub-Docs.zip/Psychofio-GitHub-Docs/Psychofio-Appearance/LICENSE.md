# Psychofio-Appearance Commercial License Agreement

Copyright (c) 2026 Psychofio Development. All rights reserved.

This software is licensed, not sold. By purchasing, downloading, installing, or using Psychofio-Appearance (the **Software**), the purchaser (**Licensee**) agrees to these terms.

## 1. License grant

Psychofio Development grants the Licensee a limited, non-exclusive, non-transferable license to install and use the Software on FiveM servers that the Licensee owns or controls and that are authorized through the Cfx.re account holding the purchased asset entitlement.

The license is delivered and enforced through Cfx.re Asset Escrow and the FiveM asset entitlement system. No separate IP address, Discord, or manual license key is required.

## 2. Permitted use

The Licensee may:

- Install and run the Software on servers owned or controlled by the Licensee, subject to Cfx.re entitlement rules.
- Edit files intentionally excluded from escrow, including configuration, locales, tattoo catalog, permissions, and SQL files.
- Create private backups for operational and disaster-recovery purposes.
- Use the Software in commercial or non-commercial FiveM servers, subject to the Cfx.re Platform License Agreement, Tebex rules, and applicable law.

## 3. Prohibited use

The Licensee may not:

- Resell, redistribute, sublicense, share, leak, publish, gift, rent, or otherwise provide the Software or any protected portion to another person or organization.
- Upload the Software to public repositories, file-sharing services, marketplaces, forums, or Discord channels.
- Attempt to decrypt, extract, bypass, disable, emulate, or interfere with Cfx.re Asset Escrow or entitlement checks.
- Remove or alter copyright, attribution, license, or third-party notice files.
- Claim authorship or ownership of the Software.
- Use the Software or its branding in a way that suggests endorsement by Cfx.re, FiveM, Rockstar Games, Take-Two Interactive, QBCore, or Tebex.
- Use the Software for unlawful activity or in violation of platform rules.

## 4. Account, entitlement, and transfer

The entitlement is linked to the Cfx.re account used for purchase. Server license keys must be owned by or properly associated with that account according to Cfx.re rules.

Transfers, subscriptions, revocations, refunds, and chargebacks are handled through Cfx.re and/or Tebex. A revoked entitlement, completed refund, fraudulent payment, or chargeback terminates this license immediately.

## 5. Updates and support

Updates and support are provided according to `SUPPORT_POLICY.md` and the active Tebex package description. Lifetime access, lifetime support, compatibility with future framework versions, and custom development are not promised unless explicitly stated in writing by Psychofio Development.

## 6. Third-party components

Third-party components remain governed by their original licenses. Required notices are included in `THIRD_PARTY_NOTICES.md`. This commercial license does not replace or restrict rights granted by those third-party licenses.

## 7. Warranty disclaimer

To the maximum extent permitted by law, the Software is provided **as is** and **as available**, without warranties of merchantability, fitness for a particular purpose, uninterrupted operation, or compatibility with every server configuration.

## 8. Limitation of liability

To the maximum extent permitted by law, Psychofio Development is not liable for indirect, incidental, special, consequential, or punitive damages; loss of revenue, data, server availability, or reputation; or damage caused by third-party resources, unsupported modifications, incorrect installation, or platform changes.

Nothing in this agreement excludes rights or liabilities that cannot legally be excluded.

## 9. Refunds and consumer rights

Refund eligibility is governed by Tebex terms, the package description, and applicable consumer law. Nothing in this agreement removes mandatory consumer rights.

## 10. Termination

This license terminates automatically if the Licensee materially breaches these terms. Upon termination, the Licensee must stop using and delete all copies of the Software, except records that must be retained by law.

## 11. Platform terms

Use of the Software is also subject to the Cfx.re Platform License Agreement, FiveM rules, Tebex Terms of Service and Acceptable Use Policy, and any other applicable platform terms. Where a platform rule conflicts with this agreement, the platform rule controls for use on that platform.

Psychofio Development is an independent creator and is not affiliated with or endorsed by Cfx.re, FiveM, Rockstar Games, Take-Two Interactive, QBCore, or Tebex.
