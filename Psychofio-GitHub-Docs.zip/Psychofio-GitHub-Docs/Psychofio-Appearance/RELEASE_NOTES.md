# Psychofio-Appearance v1.4.3

Build: `release-20260728`

## Release summary

- Complete QBCore character appearance, clothing, wardrobe and outfit system.
- Full freemode head blend, 20 face features and 13 GTA head overlays.
- Hair, eye color, beard, eyebrow, makeup and tattoo customization.
- Serialized live face updates with final-state save protection.
- Model/language tattoo catalog cache and optimized face native pipeline.
- Appearance history, comparison, outfit sharing and quick outfit slots.
- Server-side session, distance, model, URL and payload validation.
- Turkish and English user interface.
- Validated ped model name, decimal hash and hexadecimal hash input in
  `/pedmenu`.
- Optional config-based preset ped cards.

## Compatibility

- QBCore
- qb-multicharacter for the default QBCore character flow
- oxmysql
- OneSync
- Optional qb-target
- GTA freemode models for complete face editing

The database schema and saved appearance JSON are unchanged from v1.4.2.
Existing installations do not require a new SQL migration for this release.

## Upgrade

Stop the server, remove the old `Psychofio-Appearance` directory and install
the new directory from the archive. Do not merge different releases. Keep only
one active character appearance resource.

See `START_HERE.md`, `INSTALL.md`, `CHANGELOG.md` and `SUPPORT_POLICY.md`.
After installation, run `/appearancefacecheck` and complete the save/reconnect
acceptance flow documented in `INSTALL.md`.
