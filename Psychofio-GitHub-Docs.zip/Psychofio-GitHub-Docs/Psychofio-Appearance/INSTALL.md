# Hızlı Kurulum

1. Eski `Psychofio-Appearance` klasörünü yedekleyip tamamen kaldır.
2. ZIP içindeki `Psychofio-Appearance` klasörünü `resources/[local]/` altına koy.
3. `server.cfg`:

```cfg
ensure oxmysql
ensure qb-core
# QBCore varsayılan karakter akışını kullanıyorsan:
ensure qb-multicharacter
# qb-target kullanıyorsan önce onu başlat.
ensure Psychofio-Appearance
```

4. Sunucuyu tamamen yeniden başlat.
5. Konsolda `[Psychofio-Appearance] Started v1.4.3` mesajını kontrol et.
6. `qb-multicharacter` kullanıyorsan Appearance'dan önce başladığını kontrol et.
7. Admin olarak `/appearance` ve `/pedmenu` komutlarını test et.
8. Normal oyuncuyla mağaza ve job gardırop noktalarını test et.

## Kurulum doğrulama

Oyuna girdikten sonra şu komutu çalıştır:

```text
/appearancefacecheck
```

F8 konsolunda şu değerleri görmelisin:

```text
version=1.4.3 build=release-20260728 ... freemode=true conflicts=none
```

Ardından erkek ve kadın freemode karakterlerde:

1. Ten karışımını iki farklı parent skin ID ile test et.
2. 20 yüz sliderını eksi ve artı yönde hareket ettir.
3. Sakal ve kaş stilini, yoğunluğunu ve rengini değiştir.
4. Diğer 13 overlay kategorisinde stil ve yoğunluk seç.
5. Saç, göz rengi, kıyafet, prop ve dövme değiştir.
6. Kaydet, menüyü kapat, reconnect yap ve değerlerin korunduğunu doğrula.

Menü arka planında donuk kalırsa kullanılan karakter resource'unun
`Psychofio-Appearance` kaynağından önce başladığını ve client F8 konsolunda NUI
hatası olmadığını kontrol et. `freemode=false` görünürse tam yüz düzenleme için
`mp_m_freemode_01` veya `mp_f_freemode_01` kullan.



## 1.2.x sürümünden yükseltme

1. Mevcut klasör ve veritabanının yedeğini al.
2. Yeni resource dosyalarını kur.
3. Önce resource'un otomatik migration işlemini kullan. Manuel yükseltme
   gerekirse `sql/upgrade_1_3_0.sql` dosyasını çalıştır.
4. Eski client tabanlı `OpenMenu`, `OpenWardrobe` ve `AddWardrobe`
   entegrasyonlarını server exportlarına taşı.

## SQL kurulumu

Resource tabloları ve eksik kolon/indexleri başlangıçta güvenli biçimde
oluşturmayı dener. `sql/psychofio_appearance.sql` temiz kurulum için manuel
fallback'tir. `sql/upgrade_1_3_0.sql` yalnız 1.2.x kurulumunu elle yükseltmek
içindir ve mevcut indexleri kontrol ederek tekrar çalıştırılabilir.

## Discord logları (isteğe bağlı)

`shared/config.lua` içinde `Config.DiscordLogs.enabled = true` yap ve webhook'u
clientlara açılmayan `server.cfg` convar'ına koy:

```cfg
set psychofio_appearance_discord_webhook "https://discord.com/api/webhooks/..."
```

Webhook'u `shared/config.lua`, client dosyaları veya destek mesajlarına yazma.

## txAdmin / ACE yönetici bağlantısı

QBCore `admin` ve `god` yetkileri doğrudan desteklenir. ACE tarafı için server.cfg dosyasına şunu ekleyebilirsin:

```cfg
add_ace group.admin psychofio.appearance.admin allow
```

Bu ACE satırını yalnız `server.cfg` içine ekle. F8/client konsolunda veya
resource çalışırken `add_ace` komutunu çağırma; aksi durumda access denied
mesajı alırsın. Mevcut `add_ace group.admin command allow` satırı da komut ACE
fallback'i üzerinden kabul edilir.


## OneSync gereksinimi

İlk karakter oluşturma ve `/pedmenu` izolasyonu routing bucket kullandığı için txAdmin Settings içinden OneSync açık olmalıdır. `server.cfg` içine ikinci bir `set onesync` satırı eklemeyin; txAdmin tarafından yönetiliyorsa ayarı panelden açın.

## Cfx.re Asset Escrow / Tebex kurulumu

Bu resource için ayrı bir license key girilmez. Satın alma sırasında kullanılan Cfx.re hesabı, sunucunun FiveM license key hesabıyla eşleşmelidir.

`You lack the required entitlement` hatasında:

1. Assetin satın alındığı Cfx.re hesabını kontrol et.
2. Sunucudaki `sv_licenseKey` değerinin sahibi olan hesabı kontrol et.
3. Cfx Portal içindeki owned assets bölümünde assetin göründüğünü doğrula.
4. Güncel recommended FXServer artifact kullan.
5. Resource klasörünün iç içe çıkarılmadığını ve adının `Psychofio-Appearance` olduğunu kontrol et.

Tebex secret, `sv_licenseKey`, veritabanı parolası ve Discord webhookunu destek mesajlarında herkese açık paylaşma.
