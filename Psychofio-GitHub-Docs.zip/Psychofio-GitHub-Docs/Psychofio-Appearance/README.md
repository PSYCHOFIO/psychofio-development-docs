# Psychofio-Appearance v1.4.3

QBCore + oxmysql için profesyonel görünüm, kıyafet, karakter oluşturma, mağaza, gardırop ve outfit sistemi.

## v1.4.3 öne çıkanlar

- `/pedmenu` Ped Seçimi sekmesine model adı, decimal hash ve `0x` hash girişi
  eklenmiştir.
- Girilen model GTA ped native'leriyle doğrulanır; geçersiz veya ped olmayan
  modeller uygulanmaz.
- Custom ped kaydı sunucuda aktif OneSync oyuncu pediyle doğrulanır.
- Hazır ped kartları config üzerinden isteğe bağlı olarak tekrar açılabilir.

## Tam yüz motoru

- Tek otoriter yüz state'i kullanan kararlı yüz motoru
- Ten karışımı, 20 yüz morfu ve GTA overlay ID 0-12 için ortak tam-state akışı
- Head blend yalnız değiştiğinde uygulanır; sürekli head rebuild döngüsü yoktur
- GTA float native parametrelerinde açık Lua float dönüşümü
- Eski NUI cevaplarının sliderları geri sıçratmasını engelleyen tek yüz kuyruğu
- Kaydetmeden önce bekleyen yüz ayarlarını tamamlayan queue flush
- Sunucu kontrollü, süreli editör oturumları ve token doğrulaması
- Mağaza/gardırop konumu, menü modu ve izinli alanların sunucuda yeniden kontrolü
- Head blend, overlay, saç, göz, component, prop ve dövme katalog doğrulaması
- İşlem bazlı cooldown, outfit işlem kilidi ve veritabanı hatasında ücret iadesi
- İsteğe bağlı Discord güvenlik/işlem logları
- Undo/Redo ve orijinal görünüm karşılaştırması
- Outfit favorileri, klasörleri, arama ve 1-5 hızlı slotları
- Gerçek berber ve dövme mağazaları
- Mağazaya özel kategori, izinli kıyafet/aksesuar ve değişiklik bazlı fiyatlandırma
- `/pedmenu` içinde doğrulamalı ped model kodu/hash girişi
- Son outfit silindiğinde listenin doğru şekilde tamamen boşalması
- Yalnızca Discord attachment görsel bağlantısı desteği
- Gövde, kol, bacak, baş ve saç bölgelerini kapsayan tam dövme kataloğu ve bölge filtresi
- Sakal modeli, yoğunluğu ve renginin native overlay verisiyle doğru okunup uygulanması


## Kurulum

Klasör adı tam olarak:

```text
resources/[local]/Psychofio-Appearance/
```

`server.cfg` sırası:

```cfg
ensure oxmysql
ensure qb-core
# QBCore varsayılan karakter sistemini kullanıyorsan:
ensure qb-multicharacter
# qb-target kullanıyorsan:
ensure qb-target
# Özel kıyafet stream resource'larını burada başlat.
ensure Psychofio-Appearance
```

Tablolar resource başladığında otomatik oluşturulur. Manuel kurulum için:

```text
sql/psychofio_appearance.sql
```

1.2.x sürümünden yükseltiyorsan `sql/upgrade_1_3_0.sql` dosyasını çalıştırabilirsin. Resource eksik kolon ve indexleri başlangıçta otomatik oluşturmayı da dener.

## Admin komutları

`/appearance`, `/pedmenu`, `/barber` ve `/tattoo` komutları varsayılan olarak yalnızca QBCore `admin` ve `god` gruplarına açıktır.

```text
/appearance
/appearance [server id]
/pedmenu
/pedmenu [server id]
/barber
/barber [server id]
/tattoo
/tattoo [server id]
```

- `/appearance [id]`: hedef oyuncuya yalnızca outfit, kıyafet, aksesuar ve ayarlar menüsünü açar; yüz, saç, sakal ve dövme düzenlemesi bu modda yoktur.
- `/pedmenu [id]`: hedef oyuncuya tam karakter düzenleme menüsünü açar; Ped Seçimi sekmesinde geçerli bir ped model kodu/hash'i girilebilir. Yüz & Saç ve Dövmeler de bu menüde kullanılabilir.
- `/barber [id]`: hedef oyuncuya yalnızca saç, saç rengi, balyaj ve sakal düzenleme menüsünü açar.
- `/tattoo [id]`: hedef oyuncuya yalnızca Dövmeler menüsünü açar.
- Mağaza ve gardırop etkileşimleri komut değildir; gerekli job/grade şartını sağlayan oyuncular kullanabilir.

ACE desteği varsayılan olarak açıktır. `Config.AllowAdminAce = false` yapılarak kapatılabilir.

## Kıyafet paketi ekleme

Kıyafet paketlerini menü resource’una kopyalama. Her paket ayrı stream resource olarak kurulmalıdır:

```text
resources/[clothing]/my-custom-clothes/
├── fxmanifest.lua
└── stream/
    ├── *.ydd
    ├── *.ytd
    └── *.ymt
```

Basit manifest örneği:

```lua
fx_version 'cerulean'
game 'gta5'

files {
    'stream/**/*.ymt'
}

data_file 'SHOP_PED_APPAREL_META_FILE' 'stream/**/*.ymt'
```

Başlatma sırası:

```cfg
ensure my-custom-clothes
ensure eup-public
ensure Psychofio-Appearance
```

Menü bütün GTA, addon ve EUP kıyafetlerini FiveM’in normal global drawable sırasındaki tek listede gösterir. Paket seçimi veya collection rozeti yoktur. Stream resource’ları başladığında model ve texture limitleri native’lerden otomatik okunur.

## Haritaya kıyafet mağazası ekleme

`shared/config.lua` içindeki `Config.Shops` tablosuna ekle:

```lua
{
    id = 'suburban_del_perro',
    label = { tr = 'Kıyafet Mağazası', en = 'Clothing Store' },
    coords = vector3(-1194.950, -772.629, 17.325),
    heading = 117.653,
    price = 250,
    interaction = 'key',
    prompt = {
        tr = 'Kıyafet menüsünü açmak için ~INPUT_CONTEXT~ tuşuna basın',
        en = 'Press ~INPUT_CONTEXT~ to open the clothing menu'
    },
    blip = { enabled = true, sprite = 73, color = 47, scale = 0.65 }
}
```

`interaction = 'key'` kullanıldığında qb-target açık olsa bile mağazada E tuşu yardım metni gösterilir. `marker = false` ekleyerek zemin markerını kapatabilirsin.

Mağaza fiyatları örnekte Türk lirası (`₺`) ile gösterilir. Sunucunun ekonomisine göre `price` ve `Config.CurrencySymbol` değerini değiştir.

## Job gardırobu ekleme

`Config.Wardrobes`:

```lua
{
    id = 'police_mrpd',
    label = { tr = 'Polis Gardırobu', en = 'Police Wardrobe' },
    coords = vector3(461.3, -998.0, 30.7),
    job = 'police',
    minGrade = 0
}
```

- Gardırop ücretsizdir.
- Job ve minimum grade kontrol edilir.
- `qb-target` açıksa otomatik target zone kurulur.
- `qb-target` yoksa optimize marker sistemi devreye girer.

## Ev gardırobu / başka resource entegrasyonu

v1.3.x güvenli modunda client exportları varsayılan olarak kapalıdır. Başka bir **server resource** içinden hedef oyuncuya güvenli ve kısa süreli izin ver:

```lua
exports['Psychofio-Appearance']:OpenWardrobeForPlayer(source, {
    label = 'Ev Gardırobu'
})
```

Tam menü veya özel fiyatlı bir sunucu akışı için:

```lua
exports['Psychofio-Appearance']:OpenMenuForPlayer(source, {
    label = 'Özel Giyim Menüsü',
    mode = 'appearance',
    price = 0,
    defaultTab = 'clothing'
})
```

Sabit konumları mümkün olduğunca `Config.Shops` / `Config.Wardrobes` içine ekle. Eski client exportlarını yalnızca zorunlu geriye dönük uyumluluk için `Config.Security.allowLegacyExternal = true` ile aç; önerilen değer `false` olarak kalmasıdır.

## Outfit sistemi

- Kişisel outfit kaydetme, giyme, silme, yeniden adlandırma
- Paylaşım kodu oluşturma ve koddan içe aktarma; kodlar yalnızca kıyafet ve aksesuarları taşır, yüz/saç/sakal/dövme verisini değiştirmez
- Job, gang ve admin outfit kapsamı
- Oyuncu başına en fazla 15 kayıt
- Outfit kartına görsel bağlantısı ekleme
- Favori yıldızı, klasör düzenleme ve canlı arama
- Kişisel outfitler için `/outfit 1-5` hızlı slotları

### Outfit görseli

Outfit kaydederken Discord'a yüklediğin görselin attachment bağlantısını gir:

```text
https://cdn.discordapp.com/attachments/.../outfit.png
https://media.discordapp.net/attachments/.../outfit.webp
```

Yalnızca Discord attachment/CDN bağlantıları kabul edilir. Alan boş bırakılırsa Psychofio logosu görünür.

## Job ve yetki kısıtlaması

Belirli global drawable değerlerini kilitlemek için `Config.RestrictedItems`:

```lua
Config.RestrictedItems = {
    { type = 'component', id = 9, drawable = 12, jobs = { police = 0 } },
    { type = 'prop', id = 0, drawable = 45, adminOnly = true }
}
```

Sunucu kaydetme sırasında veriyi tekrar doğrular; yalnızca client kontrolüne güvenilmez.

Hazır job outfitleri `Config.JobOutfits` içine eklenebilir:

```lua
Config.JobOutfits = {
    police = {
        {
            name = 'Devriye',
            minGrade = 0,
            imageUrl = 'https://.../patrol.png',
            appearance = { -- GetAppearance export çıktısı }
        }
    }
}
```

## Dövme kataloğu ve yeni dövme ekleme

Paket, `shared/tattoos.lua` içinde gövde, sağ/sol kol, sağ/sol bacak, baş ve saç bölgelerini kapsayan tam katalogla gelir. Arayüzde bölge filtresi ve arama bulunur; karakter cinsiyetine uygun olmayan overlay kayıtları otomatik gizlenir.

Yeni kayıt örneği:

```lua
Config.Tattoos[#Config.Tattoos + 1] = {
    id = 'custom_back_01',
    label = { tr = 'Özel Sırt Dövmesi', en = 'Custom Back Tattoo' },
    zone = { tr = 'Gövde', en = 'Torso' },
    zoneKey = 'ZONE_TORSO',
    camera = 'torso',
    collection = 'my_tattoo_overlays',
    overlayMale = 'MY_TATTOO_BACK_M',
    overlayFemale = 'MY_TATTOO_BACK_F'
}
```

`zoneKey` için `ZONE_TORSO`, `ZONE_LEFT_ARM`, `ZONE_RIGHT_ARM`, `ZONE_LEFT_LEG`, `ZONE_RIGHT_LEG`, `ZONE_HEAD` veya `ZONE_HAIR` kullanılabilir.

## Ped seçimi

`/pedmenu` içindeki **Ped Seçimi** sekmesine GTA ped model adı, decimal hash
veya `0x` hash yazılabilir:

```text
s_m_y_cop_01
1885233650
0x5E3DA4A4
```

Model adı/hash önce client GTA native'leriyle doğrulanır. Model GTA model
kataloğunda yoksa, geçersizse veya ped değilse uygulanmaz. Kayıt sırasında
sunucu da gönderilen hash'in OneSync üzerinde oyuncuya uygulanmış mevcut ped
modeli olduğunu doğrular.

Bu giriş alanını kapatmak için:

```lua
Config.PedSelection.allowModelInput = false
```

Hazır model kartlarını giriş alanının altında göstermek için
`Config.PedSelection.showPresetModels = true` yapıp `Config.PedModels`
listesine model ekleyebilirsin:

```lua
Config.PedModels[#Config.PedModels + 1] = {
    model = 'a_m_y_business_02',
    label = { tr = 'İş Adamı 2', en = 'Businessman 2' },
    category = 'civilian'
}
```

Freemode olmayan modellerde yüz, sakal, saç rengi ve dövme kontrolleri otomatik devre dışı kalır. İlk karakter oluşturma ekranında ped seçimini açmak için `Config.PedSelection.allowInCharacterCreation = true` kullanılabilir. Custom ped seçimi varsayılan olarak yalnızca sunucunun izin verdiği `/pedmenu` oturumunda kullanılabilir.

## Appearance exportları

Görünüm verisini okumak ve uygulamak için client exportları kullanılabilir:

```lua
local appearance = exports['Psychofio-Appearance']:GetAppearance()
exports['Psychofio-Appearance']:SetAppearance(appearance)
exports['Psychofio-Appearance']:ConvertQbClothing(qbSkinData)
```

Menü açma işlemleri güvenlik nedeniyle server tarafında yapılır:

```lua
exports['Psychofio-Appearance']:OpenMenuForPlayer(source, options)
exports['Psychofio-Appearance']:OpenWardrobeForPlayer(source, options)
```

## Arayüz özellikleri

- Türkçe / English
- Menü boyutu ayarı
- Config tabanlı panel transparanlığı
- Hafif 3D panel efekti
- Kategoriye göre otomatik kamera
- Yumuşak kamera geçişi
- Ekrandaki oklarla karakter döndürme
- Ok tuşlarıyla aktif sliderı değiştirme
- Model ve texture değerlerini native limitlerine göre sınırlandırma
- Kategori önizleme görselleri

Önizleme SVG’lerini değiştirmek için:

```text
web/img/previews/
```

## Karakter oluşturma

- 20 yüz sliderı
- Anne/baba yüz ve ten karışımı
- Saç rengi ve highlight
- Sakal, kaş, makyaj, ruj, güneş hasarı, yaşlanma
- Göz rengi
- Ben, çil ve cilt detayları
- Config tabanlı dövme sistemi
- Erkek/kadın freemode geçişinde varsayılan uyumlu parçalar

## Optimizasyon

- Menü kapalıyken NUI/kamera döngüsü çalışmaz.
- Marker taraması uzakta 1500 ms bekler.
- `qb-target` aktifken marker taraması yapılmaz.
- Drawable/texture limitleri model-slot-drawable bazında cache edilir.
- NUI değişiklik çağrıları kısa throttle ile birleştirilir.
- Resource restart ve oyuncu yüklenmesinde kayıtlı görünüm bir kez uygulanır.

Ayarlar `Config.Performance` içindedir.

## Kamera ve karakter kontrolü

Menünün solundaki dört yuvarlak düğme sırasıyla kafa, gövde, pantolon ve ayakkabı kamerasına geçer. Karakterin iki yanındaki yuvarlak oklar karakteri 15 derece sola veya sağa döndürür. Menü açıkken karakter hard-freeze edilmez; varsayılan olarak nötr ayakta duruş ve geçici hareket kilidi kullanılır.


## Uyumluluk ve yönetim

- İlk karakter oluşturma ekranı varsayılan olarak QBCore `charinfo.gender` değerine göre freemode modeli kullanır. v1.3.2 ile `/pedmenu` için ayrı, config tabanlı ped seçimi yeniden eklenmiştir.
- `/appearance [id]`, `/pedmenu [id]`, `/barber [id]` ve `/tattoo [id]` komutları QBCore `admin/god` ile birlikte ACE kontrolünü de kabul eder.
- txAdmin/ACE kullanımı için önerilen satır: `add_ace group.admin psychofio.appearance.admin allow`.
- Menü pozu entity freeze kullanmaz; varsayılan nötr duruş ve hareket kilidi menü kapanırken iki aşamalı temizlenir.
- Karakter dönüş ve kamera düğmeleri harici PNG yerine CEF uyumlu inline SVG kullanır.


## İlk karakter oluşturma ve özel ped menüsü

- Yeni bir QBCore karakterinde kayıtlı Psychofio görünümü yoksa `QBCore:Client:OnPlayerLoaded` sonrasında ped menüsü otomatik açılır.
- İlk oluşturma menüsü görünüm kaydedilmeden kapatılamaz.
- İlk oluşturma ve `/pedmenu [id]` oturumları oyuncuyu benzersiz bir OneSync routing bucket içine alır.
- Bucket içinde population kapalıdır; başka oyuncular görünmez ve çarpışma/iç içe girme olmaz.
- Diğer oyuncular local conceal ve ses volume override ile izole edilir. Doğrudan Mumble kanal değiştirme seçeneği uyumluluk için varsayılan olarak kapalıdır.
- Menü kapanınca oyuncunun önceki routing bucket'ı ve varsayılan voice channel'ı geri yüklenir.

Bu özellik için txAdmin ayarlarında OneSync açık olmalıdır. Ayarlar `shared/config.lua` içindeki `Config.CharacterCreation` bölümündedir.


## Kamera kontrolleri

Sol kamera rayındaki Kafa, Gövde, Pantolon veya Ayakkabı düğmesine basarak ilgili açıya geçilir. Seçili düğmeye tekrar basıldığında ana tam-vücut kamerasına dönülür. Kıyafet ve yüz kontrolleri aynı açıyı tekrar istediğinde yeni kamera oluşturulmaz; bu sayede anlık görüntü sıçraması engellenir.


## Menü modları

- Appearance modu yüz düzenleyicisini içermez.
- Pedmenu modu tam yüz, head blend, saç, sakal ve makyaj düzenleyicisini içerir.
- Barber modu yalnızca saç ve sakal kontrollerini içerir.
- Kamera hedefleri karakteri dönüş düğmelerinin ortasına daha yakın gösterecek şekilde sola kaydırılmıştır.


## Dövme kataloğu
Hazır GTA dövmeleri `shared/tattoos.lua` içindedir. Arayüz karakter cinsiyetine uymayan
dövmeleri otomatik gizler. Yeni bir dövme eklerken `collection`, `overlayMale` ve/veya
`overlayFemale` alanlarını kullan.

## Yeni karakter sıfırlaması
Görünüm kaydı olmayan yeni bir QBCore karakteri açıldığında freemode ped yeniden oluşturulur;
önceki karakterin kıyafet, yüz, overlay ve dövmeleri aktarılmaz.


## Outfit paylaşım kapsamı

Outfit kayıtları ve paylaşım kodları yalnızca component `1, 3-11` ile prop verilerini saklar. Component `0` (yüz/kafa), component `2` (saç), head blend, yüz sliderları, sakal ve diğer overlay'ler, saç renkleri, göz rengi ve dövmeler outfit koduna dahil edilmez. Eski sürümde kaydedilmiş tam görünüm outfitleri yüklenirken de yalnızca kıyafet bölümü uygulanır.

Pedmenu izolasyonu menü kapanınca routing bucket, oyuncu conceal durumu ve ses override değerlerini otomatik temizler.

## Özel freemode modelleri

Özel freemode uyumlu ped modelleri kullanılıyorsa `shared/config.lua` içindeki `Config.FreemodeModels` tablosuna eklenmelidir:

```lua
Config.FreemodeModels = {
    male = 'mp_m_freemode_01',
    female = 'mp_f_freemode_01',
    -- customMale = 'custom_male_model',
    -- customFemale = 'custom_female_model'
}
```


## Hawick kıyafet mağazası

`vector4(121.08, -225.77, 54.56, 338.58)` noktasına yaklaşıldığında **Kıyafet menüsünü açmak için E tuşuna basın** yazısı görünür. E tuşu mağaza tipindeki kıyafet menüsünü açar.

## Tebex ve Cfx.re Asset Escrow

Bu sürüm Cfx.re Asset Escrow için hazırlanmıştır:

- `lua54 'yes'` etkindir.
- Core client/server Lua dosyaları escrow ile korunur.
- `shared/config.lua`, `shared/locales.lua`, `shared/tattoos.lua`, `permissions.cfg` ve SQL dosyaları müşterinin düzenleyebilmesi için `escrow_ignore` kapsamındadır.
- Ayrı IP, Discord veya manuel lisans anahtarı kullanılmaz; sahiplik kontrolünü Cfx.re asset entitlement sistemi yapar.
- Satın alan kişinin kullandığı Cfx.re hesabı ile server license key sahibinin eşleşmesi gerekir.
- Resource klasör adı `Psychofio-Appearance` olarak korunmalıdır.

Müşteri lisans koşulları `LICENSE.md`, destek kapsamı `SUPPORT_POLICY.md`, ilk kurulum özeti `START_HERE.md` içindedir.
