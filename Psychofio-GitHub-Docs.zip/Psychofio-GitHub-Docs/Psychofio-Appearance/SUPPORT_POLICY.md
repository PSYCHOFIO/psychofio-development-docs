# Support Policy

## Supported product

- Product: Psychofio-Appearance
- Version: 1.4.3
- Framework: QBCore
- Required dependencies: `qb-core`, `oxmysql`, OneSync
- Optional dependency: `qb-target`

## Included support

Support covers:

- Installation according to `START_HERE.md` and `INSTALL.md`.
- Reproducible defects in an unmodified supported version.
- Clarification of documented configuration options and exports.
- Cfx.re Asset Escrow entitlement troubleshooting when the purchaser provides the relevant console error and confirms the purchasing Cfx.re account.

## Not included

Support does not include:

- Full server installation, framework conversion, database recovery, or custom feature development.
- Conflicts caused by renamed resources, modified core files, leaked/decrypted files, unsupported forks, or outdated dependencies.
- Repairing unrelated QBCore, oxmysql, qb-target, voice, clothing-pack, artifact, hosting, or database issues.
- Guaranteeing compatibility with every custom ped, EUP pack, clothing pack, multicharacter resource, or third-party appearance resource.
- Requests made by users who cannot verify the purchase entitlement.

## Before opening a ticket

Provide all of the following:

1. Tebex transaction ID or Cfx.re asset entitlement proof.
2. Exact Psychofio-Appearance version.
3. FXServer artifact version and operating system.
4. QBCore and oxmysql versions.
5. Full server console error and client F8 error, copied as text.
6. Steps to reproduce the issue.
7. Whether the core resource was renamed or modified.
8. Relevant configuration section with secrets and webhooks removed.

## Security reports

Do not publicly disclose security issues or proof-of-concept exploits. Send a private report containing impact, reproduction steps, affected version, and suggested mitigation.

## Updates

Updates may change dependencies, configuration, database schema, or installation steps. Back up the resource and database before every update and read `CHANGELOG.md` and migration files first.

## Contact

Use the official support channel shown on the Tebex product page or in the purchase confirmation. Do not send credentials, server license keys, database passwords, Tebex secrets, or Discord webhooks in a public channel.
