# Changelog

## 1.4.3 — Ped Model Code Input

### Added
- Replaced the default preset-only ped selector with a model name/hash input.
- Added support for GTA model names, decimal hashes and hexadecimal hashes.
- Kept optional preset cards behind `Config.PedSelection.showPresetModels`.

### Security and reliability
- Rejects missing, oversized, invalid, non-CD-image and non-ped models before
  changing the player model.
- Loads the requested model before changing history, so failed requests do not
  create empty undo entries.
- Verifies unlisted saved model hashes against the active OneSync player ped;
  regular clothing/wardrobe sessions cannot inject a different ped model.
- Preserves valid selected custom ped models across save and reconnect.

## 1.4.2 — Commercial Release

### Release
- Removed internal development and reference branding from customer-facing
  source comments and documentation.
- Consolidated customer documentation for clean Cfx.re Asset Escrow delivery.
- Preserved the v1.4.1 optimized runtime, database schema and appearance JSON.

## 1.4.1 — Safe Optimization Pass

### Optimized
- Cached GTA head-overlay and hair-color limits for the resource lifetime.
- Removed repeated face-state normalization while preserving the exact native
  application order and head-blend restoration behavior.
- Cached the resolved tattoo catalog by ped model and language; selected
  tattoos are now matched with a lookup set instead of nested scans.
- Reduced duplicate component/prop limit queries, state copies and history
  fingerprint work in editor hot paths.
- Reduced NUI selector work and protected range/save queues against stale
  session responses and double-click races.

### Compatibility
- Database schema and saved appearance JSON remain unchanged.
- The v1.4.0 face engine behavior, 70 ms NUI debounce, final save flush and all
  20 face feature / 13 overlay writes are preserved.

## 1.4.0 — Full Face Engine v2

### Fixed
- Replaced the fragmented face update path with one authoritative, full-state
  face draft for head blend, all 20 face features and all 13 GTA overlays.
- Removed the 350 ms `SetPedHeadBlendData` reapply loop that could rebuild the
  head after a beard, eyebrow or morph briefly appeared.
- Explicitly coerced head-blend mixes, face-feature values and overlay opacity
  to Lua floats before calling GTA natives.
- Serialized every face group through a single latest-state queue; stale NUI
  callback responses can no longer roll newer controls backwards.
- Pending face edits are flushed before saving, so the final slider movement is
  included in the database JSON.
- Added numeric/string-key and legacy overlay normalization on the client.
- A head-blend change now waits for the rebuild to finish, then restores face
  features and overlays once in the deterministic engine order.

## 1.3.4 — Player Editor State Isolation

### Fixed
- External ped captures and appearance applications can no longer overwrite the
  local player's editor `currentState`.
- Face reapplication is now restricted to the current local player ped.
- Removed cross-resource installation and schema references from this standalone
  Appearance package.

## 1.3.3 — Face Core Stabilization

### Fixed
- Face feature and head-overlay state is held by the active editor instead of
  being rebuilt from transient native reads after every rapid request.
- Freemode head blend, overlay, opacity and color data is reapplied after
  delayed framework/model activity while the editor remains open.
- Added runtime face diagnostics and neutral editor posing.

## 1.3.2 — Beard Plus Button Stability Fix

### Fixed
- Separated GTA's `255` empty facial-hair state from beard style `0` by representing an empty beard as `-1` inside the editor.
- Fixed the first `+` press skipping or corrupting the first beard style.
- Serialized rapid overlay requests so an older response cannot overwrite a newer beard selection.
- Preserved beard opacity and color while moving between styles.
- Fixed clearing a beard and selecting the first beard again.
- Added server-side support for the normalized `-1` empty-overlay value.

## 1.3.1 — Ped, Outfit, Tattoo & Beard Fixes

### Added
- Added a config allowlist-based **Ped Selection** tab to `/pedmenu`.
- Added model persistence for approved custom ped models.
- Expanded the tattoo catalog to 869 entries across torso, both arms, both legs, head and hair zones.
- Added tattoo search, zone filtering and per-zone camera presets.

### Fixed
- Fixed the final remaining outfit card not disappearing after the last saved outfit was deleted.
- Fixed beard style, opacity and color values being lost or reset by reading the actual ped head-overlay state.
- Beard style selection now automatically restores visible opacity when a style is chosen from a hidden state.
- Fixed tattoo browsing being limited to torso entries.

### Changed
- Outfit images now accept only Discord attachment/CDN URLs.
- Removed support and documentation for external image-page links.
- Non-freemode ped models automatically disable incompatible face, beard and tattoo controls.
- Version bumped to 1.3.1.

## 1.3.0 — Tebex / Asset Escrow Packaging

- Added Cfx.re Asset Escrow metadata and an explicit `escrow_ignore` list.
- Added commercial license, customer start guide, support policy, and entitlement troubleshooting.
- Added OneSync as a manifest runtime dependency.
- Added copyright headers to core Lua and NUI source files.
- Expanded third-party notices with the required MIT license text.
- No custom IP lock, remote code loader, obfuscator, or manual license-key system was added.

## 1.3.0 — Security & Player Experience

### Security
- Added server-issued editor tokens with expiration, player and context binding.
- Added server-side distance, access, mode and allowed-field enforcement.
- Added strict validation for components, props, palettes, head blend, overlays, hair, eyes and tattoo catalog IDs.
- Added operation cooldowns, outfit locks and restricted legacy external client integrations.
- Added payment refund handling when appearance persistence fails.
- Added optional Discord logs for security denials, saves and outfit actions.

### Player experience
- Added Undo/Redo history and original appearance comparison.
- Added outfit favorites, folders and search.
- Added five configurable quick outfit slots with `/outfit [1-5]`.
- Added physical barber and tattoo shop location support.
- Added shop-specific clothing/prop availability and change-based pricing.

### Database / integration
- Added `favorite`, `folder` and `quick_slot` outfit fields with automatic migration.
- Added secure server exports: `OpenMenuForPlayer` and `OpenWardrobeForPlayer`.
- Version bumped to 1.3.0.

# v1.2.1

- Outfit silme işlemindeki yerleşik tarayıcı `confirm()` penceresi kaldırıldı; FiveM NUI ile uyumlu özel onay modalı eklendi.
- Silme, kaydetme ve yeniden adlandırma işlemlerine çift tıklama/tekrar istek koruması eklendi.
- Sunucudan dönen outfit listesi NUI tarafında doğrudan işleniyor; hydrate beklenmeden kartlar güncelleniyor.
- Outfit görsellerine tıklayarak büyük, oranı korunmuş önizleme açma desteği eklendi.
- ESC ve modal arka planına tıklama davranışları düzeltildi.

## 1.2.0 - Psychofio Marka ve Arayüz Yenilemesi

- Resource adı `Psychofio-Appearance` olarak değiştirildi.
- Tüm event, callback, export örnekleri, ACE izinleri ve SQL tablo adları Psychofio ad alanına taşındı.
- Arayüz paleti Psychofio logosundaki siyah, kırmızı ve kırık beyaz renklerle baştan düzenlendi.
- Logo, önizleme kartları, butonlar, sliderlar, kamera rayı ve panel ışık efektleri yeni stile uyarlandı.
- Eski marka dosyaları ve referansları kaldırıldı.

## 1.1.7 - Kıyafetçi Konum ve Görünür Prompt Düzeltmesi

- Hawick kıyafet mağazası koordinatı `vector4(121.08, -225.77, 54.56, 338.58)` olarak düzeltildi.
- Mağaza `qb-target` çalışsa bile E tuşu etkileşimini kullanır.
- Yaklaşınca mağazanın üzerinde görünür 3D `[E]` bilgilendirmesi ve yakın mesafede GTA yardım metni gösterilir.
- Etkileşim mesafesi mağaza bazında ayarlanabilir hale getirildi.

## 1.1.6 - Clothing Store E Interaction

- Del Perro/Suburban kıyafet mağazası `vector3(-1194.950, -772.629, 17.325)` koordinatına eklendi.
- Mağaza `qb-target` açık olsa bile doğrudan E tuşu etkileşimini kullanır.
- Yaklaşınca `Kıyafet menüsünü açmak için E tuşuna basın` yardım metni gösterilir.
- E tuşuyla yalnızca kıyafet/outfit/aksesuar düzenleyicisi olan mağaza görünümü açılır.
- Config mağazalarına `interaction = 'key'`, `prompt`, `heading` ve isteğe bağlı `marker = false` desteği eklendi.

## 1.1.5 - Tattoo Command Separation

- Yeni `/tattoo [id]` komutu yalnızca `Dövmeler` sekmesini açar.
- `/appearance [id]` menüsünden `Dövmeler` sekmesi kaldırıldı; bu mod artık yalnızca outfit, kıyafet, aksesuar ve ayarları içerir.
- `/appearance` içinden NUI manipülasyonuyla dövme değiştirme engellendi.
- `/pedmenu` ve ilk karakter oluşturma menüsü dövme düzenleme yetkisini korur.
- `/tattoo` modunda outfit kaydetme düğmesi gizlenir ve ana kayıt düğmesi `Dövmeleri Kaydet` olarak gösterilir.
- QBCore admin/god ve ACE komut yetkisi `/tattoo` için genişletildi.

## 1.1.4 - Command Mode & Freemode Compatibility Fix

- `/appearance` menüsünden `Yüz & Saç` sekmesi kaldırıldı.
- `/appearance` üzerinden NUI manipülasyonuyla yüz, head blend, saç, sakal, overlay veya göz rengi değiştirilmesi client tarafında engellendi.
- `/barber` yalnızca saç modeli/renkleri ve sakal kontrollerini düzenlemeye devam eder.
- `/pedmenu` tam yüz, saç ve sakal editörü olarak korunur.
- Freemode uyumluluk kontrolü sabit GTA model hashleri yerine `Config.FreemodeModels` üzerinden yapılır.
- Özel freemode/EUP model adları ek anahtarlar veya dizi girdileri olarak tanımlandığında yüz, saç ve sakal kontrolleri artık yanlışlıkla kilitlenmez.

## 1.1.3 - Character Function Hotfix

- `applyForCharacter`, `resetCharacterForCreation` ve `forceCharacterFreemode` yardımcıları geri eklendi.
- Oyuncu yüklenirken kayıtlı görünümün uygulanmasını engelleyen nil-function hatası düzeltildi.
- İlk karakter oluşturma ve `/appearance` / `/pedmenu` açılışlarında freemode ped hazırlama tekrar çalışır hale getirildi.

## 1.1.2 - Static Pose & Mouse Parallax
- `FreezeEntityPosition` tabanlı editör kilidi kaldırıldı; ped animasyonun sabit bir karesinde tutuluyor.
- Menü kapanışında hem eski hem güncel ped için animasyon taskı ve olası eski freeze güvenli biçimde temizleniyor.
- Mouse ekran kenarlarına yaklaştıkça panelin perspektif, eğim ve konumunun yumuşak tepki verdiği 3D parallax geri getirildi.
- Panel köşeleri tekrar 24px yumuşatıldı; üst ve alt bar köşe yapısı panelle eşleştirildi.
- Kamera presetleri kullanıcının verdiği yeni body/face/torso/legs/feet değerleriyle güncellendi.

## 1.1.1 - Pose Lock & 3D UI
- Menü açıkken oyuncu pedi gerçek dünya koordinatına sabitlendi; kıyafet/slider callbacklerinde animasyon artık yeniden başlatılmıyor.
- Gecikmeli pose cleanup threadlerinin yeni açılan menüyü çözmesi engellendi.
- Arka plan şeffaflığı ayarı arayüzden kaldırıldı ve okunabilirlik sabit değere alındı.
- Ana paneldeki dört köşe CEF artefaktı için panel köşeleri düzleştirildi.
- Menü, kartlar ve butonlara katmanlı 3D gölge/basılma efektleri eklendi.
- Sidebar, kamera, döndürme, sıfırlama, kapatma, kaydetme ve +/- simgeleri yenilendi.

## 1.1.0
- Slider sürükleme sistemi yeniden yazıldı; aktif sürgü NUI yanıtlarıyla yeniden oluşturulmuyor.
- Tüm model, doku, saç, sakal ve yüz değerlerine klavyeden yazılabilen sayı kutuları eklendi.
- Kıyafetler listesinden component 0 (Yüz / Kafa) tamamen kaldırıldı.
- Component 10 Türkçe etiketi `Çıkartmalar` olarak sabitlendi.
- Saç ve sakal kontrollerinde aynı karta ait isteklerin sıralaması düzeltildi.
- Kıyafet kodu kopyalama sırası CEF kullanıcı aktivasyonuna uygun hale getirildi; başarısız olursa seçilebilir kod penceresi açılır.
- Outfit/kıyafet kodları yalnızca giyilebilir componentler ve proplar içerir.
- Pedmenu izolasyonu kapandıktan sonra routing bucket, conceal, alpha ve ses override temizliği güçlendirildi.

## 1.0.9

- Vurgu renkli range/slider kontrolü özel track ve thumb ile yeniden çizildi; sürükleme sırasında NUI'nin yeniden render edilmesi kaldırıldı.
- Saç ve sakal kontrollerindeki istek yarışları giderildi; sakal modeli seçildiğinde yoğunluk otomatik görünür seviyeye gelir.
- Kıyafetler sekmesinden Yüz/Kafa componenti kaldırıldı.
- `Rozet / Baskı` adı `Çıkartmalar` olarak değiştirildi.
- Outfit kaydı ve paylaşım kodu yalnızca kıyafet componentlerini ve aksesuar proplarını taşır; yüz, saç, sakal, head blend, makyaj, göz rengi ve dövmeler kopyalanmaz.
- Paylaşım kodu panoya kopyalama için FiveM native, Clipboard API ve CEF fallback zinciri eklendi.
- Pedmenu izolasyonu kapanırken routing bucket, conceal ve ses override temizliği tekrarlarla güvenli hale getirildi.

## 1.0.8
- Rotation controls moved into a compact cluster beside the panel.
- All camera presets shifted the character farther left.
- Added a gender-aware base tattoo catalog and tattoo camera focus.
- New character creation now recreates a clean freemode ped so previous-character data cannot leak.
- Client appearance state is cleared on QBCore player unload.

# v1.0.7

- Karakter kamera kadrajı sola alınarak sağ/sol dönüş düğmelerinin ortasına yaklaştırıldı.
- `/appearance` menüsünden Yüz & Saç sekmesi kaldırıldı.
- `/barber [id]` komutu eklendi; yalnızca saç ve sakal düzenler.
- `/pedmenu [id]` tam Yüz & Saç düzenleyicisini korur.
- Menü modlarına göre NUI ve client callback izinleri sınırlandırıldı.

## 1.0.6

- Slider veya kıyafet değişiminde aynı kamera presetinin tekrar tekrar oluşturulması engellendi.
- Hızlı kamera geçişlerinde eski transition thread'inin yeni kamerayı silmesine neden olan yarış durumu düzeltildi.
- Kamera havuzu ve güvenli kamera temizliği eklendi.
- Kamera rayında seçili Kafa/Gövde/Pantolon/Ayakkabı düğmesine tekrar basınca ana gövde kamerasına dönüş eklendi.
- Ana kameraya dönüldüğünde kamera rayındaki aktif işaret temizlenir.

## 1.0.5

- Yeni QBCore karakterinde kayıtlı görünüm yoksa ped menüsü otomatik açılır.
- İlk karakter oluşturma menüsü kaydetme zorunluluğu ile çalışır.
- İlk oluşturma ve `/pedmenu` için özel OneSync routing bucket eklendi.
- Ped menüsünde diğer oyuncuların görünmesi, duyulması ve oyuncuların iç içe girmesi engellendi.
- Menü kapanınca routing bucket, Mumble channel, conceal ve volume override değerleri temizlenir.
- Player unload ve resource stop için güvenli oturum temizliği eklendi.

## 1.0.4
- Karakter kamerası editör alanının merkezine hizalandı.
- Sağ/sol dönüş kontrolleri karakter merkezine göre simetrik yerleştirildi.
- Editör pozu `mini@strip_club@lap_dance@ld_girl_a_wait / ld_girl_a_wait` olarak değiştirildi.
- Kıyafet kartı kontrolleri taşmayacak şekilde yeniden düzenlendi; artı/eksi düğmeleri tüm kartlarda görünür.
- Menü kapanışında animasyon task temizliği güçlendirildi.

## 1.0.3
- Karakter dönüş düğmelerindeki CEF/backdrop siyah kutu problemi giderildi.
- Dönüş düğmeleri eşit ve gerçek dikey merkeze hizalandı.
- Statik ve dinamik buton simgeleri inline SVG ile yenilendi.
- Menü animasyonu kapanışında kalan task/hareket kilidi düzeltildi.
- QBCore admin/god yanında ACE ve group.admin command fallback eklendi.
- Manuel ped seçimi kaldırıldı; karakter modeli QBCore charinfo.gender ile freemode erkek/kadın olarak sabitlendi.
- `/pedmenu` komutu manuel ped listesi yerine hedef karakteri doğru cinsiyet freemode modeline hazırlayıp yüz menüsünü açar.
- Küçük yinelenen kod blokları temizlendi.

## 1.0.2
- Kamera rayı, dönüş düğmeleri ve animasyonlu editör pozu eklendi.
