# Third-Party Notices

Psychofio-Appearance includes GTA V tattoo overlay metadata. The included
third-party portion is limited to collection/hash identifiers and display
labels. The following copyright and license notice applies to that material:

---

MIT License

Copyright (c) 2021 snakewiz

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

---

FiveM and Cfx.re are trademarks or services of their respective owners. Grand Theft Auto V, Rockstar Games, and Take-Two Interactive are trademarks of their respective owners. QBCore, oxmysql, qb-target, and Tebex are owned by their respective authors or organizations. Their names are used only to describe compatibility and dependencies.
