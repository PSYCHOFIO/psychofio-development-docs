# Psychofio-NPC özel animasyon entegrasyonu

## Normal kurulum: işlem gerektirmez

Psychofio-NPC çalışan resource manifestlerini ve yaygın animasyon listesi
yollarını kendisi tarar. Sunucuda RPEmotes, DPEmotes, Scully veya benzeri bir
menünün okunabilir Lua/JSON listesi varsa animasyonlar ve prop seçenekleri
başlangıçta otomatik alınır. Aşağıdaki JSON/export yöntemleri yalnızca şifreli
veya alışılmadık provider geliştirenler için ileri seviye uyumluluk yollarıdır.

## Otomatik JSON keşfi

Custom animasyon resource'unun köküne `psychofio_npc_anims.json` koyun:

```text
my-custom-anims/
├── fxmanifest.lua
├── psychofio_npc_anims.json
└── stream/
    └── custom_anims.ycd
```

Örnek:

```json
{
  "animations": {
    "customwave": {
      "type": "anim",
      "dict": "custom_anim_dict",
      "clip": "custom_wave_clip",
      "flag": 49,
      "duration": -1
    },
    "guardpose": {
      "type": "scenario",
      "scenario": "WORLD_HUMAN_GUARD_STAND"
    }
  }
}
```

Farklı yol için animasyon resource'unun `fxmanifest.lua` dosyasına şunu ekleyin:

```lua
psychofio_npc_animation_file 'data/my_animations.json'
```

`psychofio_npc_anim_file` metadata adı da desteklenir.

## Sunucudaki mevcut Lua animasyon listesini kullanma

Psychofio-NPC çalışan bütün resource'larda yaygın animasyon listesi yollarını
otomatik dener. Ayrıca resource manifestindeki Lua/JSON yollarını; resource veya
dosya adı `rpemotes`, `dpemotes`, `scully`, `emote`, `animation`, `anims`,
`dance` ya da `pose` işareti taşıyorsa kendisi tarar. Alıcı NPC configine
animasyon kopyalamaz.

Hem RPEmotes/DPEmotes positional biçimi:

```lua
["burger"] = {
    "anim@heists@box_carry@",
    "idle",
    "Burger",
    AnimationOptions = {
        EmoteLoop = true,
        EmoteMoving = true,
        Prop = "prop_cs_burger_01",
        PropBone = 60309,
        PropPlacement = { 0.05, 0.01, -0.02, 10.0, 20.0, 30.0 },
        SecondProp = "prop_food_bs_cups02",
        SecondPropBone = 28422,
        SecondPropPlacement = { 0.01, 0.02, 0.03, 0.0, 0.0, 90.0 }
    }
}
```

hem de `dict/clip`, `dictionary/animation` gibi isimli alanlar desteklenir.
Lua tarayıcı dış resource kodunu çalıştırmaz; yalnızca statik tablo verisini
okur. Yeni resource başladığında liste otomatik alınır; elle yenilemek isterseniz
`/npcanimreload` kullanabilirsiniz. Prop, animasyonla birlikte her clientta
yerel olarak oluşturulur, belirtilen ped kemiğine bağlanır ve animasyon
durdurulduğunda/değiştiğinde veya NPC silindiğinde temizlenir.

## Server export ile kayıt

```lua
exports['Psychofio-NPC']:RegisterAnimation('customwave', {
    type = 'anim',
    dict = 'custom_anim_dict',
    clip = 'custom_wave_clip',
    flag = 49,
    duration = -1
})
```

Toplu kayıt:

```lua
exports['Psychofio-NPC']:RegisterAnimations({
    customwave = {
        type = 'anim',
        dict = 'custom_anim_dict',
        clip = 'custom_wave_clip',
        flag = 49,
        duration = -1
    }
})
```

`Psychofio-NPC`, export kaydı yapan resource'dan önce başlatılmalıdır.
