# Asset Escrow and Entitlement Guide

## Customer checklist

- Download the asset from the Cfx.re account that owns the purchase entitlement.
- Keep the delivered resource structure and folder name intact.
- Use a current FiveM server artifact.
- Make sure the server license key is linked to the correct Cfx.re account.
- Do not rename, merge, decrypt, or redistribute protected core files.
- Restart the server fully after replacing an escrowed resource.

## Common entitlement error

When the server reports that it is not entitled to use the resource, verify the purchasing Cfx.re account, server license key ownership, and the asset download source. The seller cannot manually bypass or generate Cfx.re entitlement.

## Editable files

The files listed in `escrow_ignore` remain customer-editable. Protected core code should not be edited directly.
