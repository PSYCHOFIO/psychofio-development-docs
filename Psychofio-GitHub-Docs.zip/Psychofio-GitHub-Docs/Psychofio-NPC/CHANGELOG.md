# Psychofio-NPC v3.5.2

- Eski sunucu yetki yöntemi, ilgili ayarlar ve çalışma zamanı kontrolleri tamamen
  kaldırıldı. `auto` modu yalnızca QBCore/ESX framework yetkilerini çözer.
- Satış paketi kod/SQL/config dosyalarıyla sınırlandı; Markdown belgeleri
  GitHub'da paylaşılmak üzere ayrı bir belge paketine taşındı.
- Legacy server authorization settings and runtime checks were removed.
- Customer runtime archives now exclude Markdown documentation, which is
  distributed separately as a GitHub-ready documentation bundle.

# Psychofio-NPC v3.5.1

- Otomatik dosya keşfi ile aynı resource'un runtime export kayıtları ayrı
  kaynak adlarına alındı; gecikmeli taramanın custom animasyonu silmesi önlendi.
- Başarısız/çakışan export kayıtlarının reload sonrasında yanlışlıkla aktif
  hale gelmesine neden olan runtime registry kalıcılık hatası giderildi.
- Ticari dağıtımdaki placeholder lisans cümlesi ve iç geliştirme belgesi
  temizlendi.
- Satış ZIP'i runtime, müşteri configi, SQL, kurulum, destek ve yasal belgelerle
  sınırlandı; test harness ve iç test raporu pakete alınmaz.

# Psychofio-NPC v3.5.0

- Custom animasyonların NPC configine kopyalanması kaldırıldı.
- Çalışan bütün resource'larda yaygın animasyon liste yolları otomatik taranır.
- Resource manifestindeki animasyon/emote/pose işaretli Lua ve JSON dosyaları
  alıcı ayarı gerektirmeden keşfedilir.
- Sonradan başlayan animasyon resource'ları `onResourceStart` üzerinden
  otomatik içeri alınır.
- Tek `Config.Language` ayarı NUI, AnimPos paneli, client/server alertleri,
  komut yardımları, F8 ve server durum metinlerini birlikte değiştirir.
- 166 gerçek kullanıcı/console mesajı EN kapsam testinden geçirildi.
- Psychofio-Appearance kaynak dosyalarında değişiklik yapılmadı.

# Psychofio-NPC v3.4.0

- Bildirim dili ve menü dili `Config.Language` ile `Config.MenuLanguage`
  üzerinden bağımsız `tr/en` seçilebilir hale getirildi.
- Yerleştirme NUI'si, seçim NUI'si, tuş isimleri ve AnimPos oyun içi yardım
  panelindeki sabit metinler iki dilde tamamlandı.
- Standart dışı animasyon dosyaları için
  `Config.AnimationDiscovery.ResourceFiles` eşlemesi eklendi.
- `Config.CustomAnimations` ile custom YCD dict/clipleri doğrudan
  Psychofio-NPC kayıt sistemine eklenebilir.
- Otomatik Lua keşfi positional RPEmotes/DPEmotes tablolarının yanında
  `dict/clip`, `dictionary/animation` gibi isimli alanları da okur.
- `AnimationOptions` içindeki loop/moving, `Prop`, `PropBone`,
  `PropPlacement`, `SecondProp` ve ikinci prop yerleşimi korunur.
- Prop modeli string adının yanında sayısal model hash kabul eder; ped scope'tan
  çıktığında kalan local prop objeleri de temizlenir.
- Dil, custom kaynak keşfi ve iki proplu animasyon akışı ayrı Fengari mock
  testiyle doğrulandı.
- Psychofio-Appearance kaynak dosyalarında değişiklik yapılmadı.

# Psychofio-NPC v3.3.7

- Seçim başarılı olmasına rağmen yönetim payload'ından çıkarılan kalıcı
  `npcId` geri eklendi; NetID, model ve koordinatla birlikte servera gönderilir.
- Ortak `validateSelectedEntity` kapısı runtime + SQL kimlik listesini kullanacak
  şekilde yeniden kuruldu.
- Server ped handle OneSync scope dışında kalsa bile yetki, model, kayıtlı
  koordinat, oyuncu mesafesi ve routing bucket doğrulandıktan sonra yönetim
  işlemi kabul edilir.
- Etiket, bakış, dönüş ve AnimPos SQL güncellemeleri serverda yapılır; görsel
  sonuç serverın oluşturduğu kimlik paketiyle entityyi gören clientlara uygulanır.
- Animasyon dispatch'i server ped handle olmadan doğrulanmış seçili NetID ile
  çalışabilir.
- Gerçek `selectedTag`, `selectedLook`, `selectedTurn`, `selectedAnimPosition`
  ve `selectedAnim` handlerları server ped handle `nil` bırakılarak mock
  runtime altında çalıştırıldı ve tamamı başarılı oldu.
- Psychofio-Appearance kaynak dosyalarında değişiklik yapılmadı.

# Psychofio-NPC v3.3.6

- `v3.3.5`teki server entity handle zorunluluğu kaldırıldı. `/npcselect`,
  `/npcdelete` ve `/npcclear` artık runtime kayıtlarını hafif SQL kimlik/konum
  listesiyle birleştirir.
- OneSync scope/ownership geçişinde ped server tarafından geçici olarak
  çözülemese bile kalıcı NPC ID'si ve kayıtlı koordinat üzerinden hedef bulunur.
- NPC oluşturma onayı entity henüz client scope'una dönmemiş olsa bile kalıcı
  kimliği client cache'e yazar; kimlik iyileştiricisi entity bağlantısını tamamlar.
- Silme işlemi ID, model, NetID ve koordinat içeren kimlik paketiyle tüm
  clientlara yayınlanır; server handle yoksa client doğru pedi koordinatla bulur.
- SQL NPC'sinde server entity handle özellikle `nil` bırakılarak gerçek
  `/npcselect`, `/npcdelete` ve `/npcclear` event handlerları mock runtime altında
  çalıştırıldı ve üçü de başarılı oldu.
- Psychofio-Appearance kaynak dosyalarında değişiklik yapılmadı.

# Psychofio-NPC v3.3.5

- `/npcdelete` ve `/npcclear` hedefleri artık client statebag'inden değil,
  sunucunun yönetilen NPC listesinden belirlenir.
- SQL satırının gerçekten silindiği tekrar okunarak doğrulanmadan dünya entity'si
  ve runtime kaydı kaldırılmaz. SQL hatasında NPC yerinde kalır ve açık hata döner.
- Client, server onayı gelmeden NPC'yi yerel olarak silmez ve sahte başarı
  bildirimi göstermez.
- Normal `/npcselect`, varsayılan olarak sunucudaki en yakın yönetilen NPC'yi
  seçer. Nişangâhlı seçim `/npcselect aim` olarak korunur.
- Varsayılan `ControlMode = "permission"` ile yetkili adminlerin yönetilen
  NPC'leri seçmesi ve kontrol etmesi sağlandı; `creator` modu isteğe bağlıdır.
- Psychofio-Appearance kaynak dosyalarında değişiklik yapılmadı.

# Psychofio-NPC v3.3.4

- `/npcselect` artık NPC_ID/owner statebag replikasyonunu beklerken oluşturulan
  network NPC'yi client tarafında erken reddetmez; son karar sunucuda verilir.
- Client kimlik çözme süresi ağ gecikmesine dayanacak şekilde artırıldı.
- Bilinen kalıcı NPC ID'si server kimlik çözücüsüne güvenli ipucu olarak eklenerek
  yeni oluşturulan NPC'nin NetID/statebag yarışında kaybolması engellendi.
- Rate-limit reddi artık clientı cevapsız bırakıp zaman aşımına düşürmez.
- Stale/reused NetID seçimleri kalıcı ID, model ve koordinat eşleşmesi olmadan
  kabul edilmez.

# Psychofio-NPC v3.3.3

- Psychofio-Appearance entegrasyonu tek yönlü ve salt-okunur hale getirildi;
  NPC yalnızca `GetAppearance` ve `IsFreemodePed` exportlarını okur.
- Kıyafet componentleri yüz motorundan önce uygulanarak component 0 sonrasında
  sakal, kaş, head blend ve yüz şekillerinin silinmesi engellendi.
- Appearance overlay verisinde bulunmayan renk türleri GTA overlay kimliğine
  göre doğru biçimde tamamlanır.
- Eksik Appearance verisinin sessizce yalnızca component/prop verisine düşmesi
  kaldırıldı; yerleştirme açıklayıcı hatayla güvenli biçimde iptal edilir.
- Stale/reused NetID uygulamaları model, NPC ID ve koordinatla doğrulanır.
- Appearance statebag'i yalnızca kalıcı `psychofioNpc:id` taşıyan NPC'ye uygulanır.
- `/psynpcappearancecheck` bağlantı ve görünüm şeması kontrolü eklendi.

# Psychofio-NPC v3.3.2

- Tüm statebag anahtarları `psychofioNpc:*` ad alanına taşındı.
- NPC appearance uygulamasının oyuncu pedine yazması tüm client girişlerinde engellendi.
- Server kayıt doğrulaması artık oyuncu pedini NPC olarak kabul etmiyor.
- Stale/reused NetID durumunda server entity çözme, statebag, yapılandırma ve silme
  sınırlarının oyuncu pedine dokunması engellendi.
- Silah, bakış, konum, yön, animasyon, collision, identity ve hard-delete client
  yollarına merkezi oyuncu-ped koruması eklendi.
- Eksik `faceFeatures` değerlerinin otomatik olarak `-1` yazılması engellendi.
- Kısmi appearance verisinde eksik saç, göz rengi ve dövme alanları artık mevcut
  NPC görünümünü varsayılan değerlere sıfırlamıyor.
- Appearance statebag çakışmasının oyuncu yüzünü sonradan sıfırlaması giderildi.

# Psychofio-NPC v3.3.1

- NPC seçimi artık client tarafındaki owner statebag'ine bağlı değildir.
- Seçim onayı her zaman sunucuda gerçek NPC sahipliğiyle doğrulanır.
- Sahiplik kuralı kullanıcının talebine uygun olarak yalnızca oluşturan server ID üzerinden çalışır.
- Aynı ID'ye ait NPC'nin license/identifier uyuşmazlığı yüzünden reddedilmesi düzeltildi.
- Statebag veya client cache gecikmesinde kendi NPC'sinin seçilememesi düzeltildi.

# Psychofio-NPC v3.3.0 — Session Ownership

## Türkçe

- Her oluşturulan NPC, oluşturan oyuncunun o anki FiveM server ID'sine bağlandı.
- `/npcselect` yalnızca yerel oyuncunun oluşturduğu NPC'leri kırmızı seçim vurgusuna alıyor.
- İsim, bakış, yön, animasyon, AnimPos, kopyalama ve silme işlemleri yalnızca NPC sahibinden kabul ediliyor.
- Başka bir admin veya yetkili oyuncu, kendisinin oluşturmadığı NPC'yi kontrol edemiyor.
- NPC sahibi sunucudan çıktığında ona ait NPC'ler dünyadan ve `psychofio_npcs` tablosundan tamamen siliniyor.
- Resource `ensure` ile yeniden başlatılırsa sahibi hâlâ aynı oturumdaysa NPC yeniden yükleniyor.
- Sahibi çevrimdışı olan veya eski sürümden kalan sahipsiz SQL kayıtları başlangıçta otomatik temizleniyor.
- `owner_source` ve `owner_identifier` veritabanı alanları eklendi.
- Sahip bazlı temizlik sorguları için `idx_owner_source` indeksi eklendi.

## English

- Every created NPC is now bound to the creator's current FiveM server ID.
- Server-ID ownership is also validated against the player's license identifier for safety.
- `/npcselect` only highlights NPCs created by the local player.
- Name, look, heading, animation, AnimPos, copy, and deletion actions are accepted only from the NPC owner.
- Other administrators or authorized players cannot control NPCs they did not create.
- When the owner disconnects, all NPCs created by that server ID are removed from both the world and the `psychofio_npcs` table.
- After a resource `ensure`, NPCs are restored only when the same owner is still connected in the same session.
- Offline-owner and legacy unowned SQL rows are automatically removed during startup.
- Added the `owner_source` and `owner_identifier` database columns.
- Added the `idx_owner_source` index for owner cleanup queries.

# Psychofio-NPC v3.2.4

## Interactive NPC Selection

- Integrated the Psychofio-Prop interactive select-mode workflow into Psychofio-NPC.
- `/npcselect` now opens a crosshair-based selection mode instead of automatically choosing the nearest NPC.
- Managed NPCs under the crosshair receive a red outline, marker, and camera trace.
- Confirm with Enter or left click; cancel with Backspace or Escape.
- Kept `/npcselect nearest` as a diagnostic fallback for the previous server-nearest selection path.
- Added Turkish and English selection overlay text.
- Selection still resolves and validates the persistent NPC identity before committing it.

# Psychofio-NPC Changelog

## v3.2.3 — Restart Duplicate & NPC Selection Hotfix

### Türkçe

- Resource `ensure`/restart sonrasında SQL kayıtlarının koşulsuz yeniden spawn edilmesi kaldırıldı.
- Aynı SQL kaydına ait mevcut network ped artık yeniden kullanılır ve kimliği tekrar bağlanır.
- Aynı model ve konumda kalan fazladan ghost NPC entityleri ayrı NetID üzerinden temizlenir.
- İlk yüklemeden sonra 2,5 / 7 / 15 saniyelik gecikmeli duplicate temizlik geçişleri eklendi.
- `/npcselect` client raycast/statebag tahmini yerine sunucunun yönettiği en yakın kalıcı NPC'yi seçer.
- Yakın seçim routing bucket, gerçek server entity ve maksimum seçim mesafesi üzerinden doğrulanır.
- Seçim sonucu NPC ID ve NetID ile clienta geri gönderilir; ardından client entity binding yenilenir.
- Seçilen NPC bildirimi artık kalıcı NPC ID'sini gösterir.
- SQL kayıtlarına dokunmadan mevcut fazla ghost entityleri temizlemek için `/npcdedupe` komutu eklendi.

### English

- Removed unconditional SQL NPC respawning after a resource `ensure`/restart.
- Existing network peds matching a persistent SQL record are now adopted and rebound instead of duplicated.
- Extra ghost entities at the same model and position are removed by their exact NetID.
- Added delayed duplicate cleanup passes at 2.5, 7, and 15 seconds after startup.
- `/npcselect` now selects the nearest persistent NPC from the server-managed registry instead of relying on client raycast/statebag timing.
- Server selection validates routing bucket, real entity existence, and maximum selection distance.
- The selected NPC ID and NetID are returned to the client and rebound before use.
- Selection notifications now include the persistent NPC ID.
- Added `/npcdedupe` to remove current extra ghost entities without deleting SQL records.

## v3.2.2 — Nearby NPC Selection Fix

### Fixed
- `/npcselect` now prioritizes the nearest managed NPC within 3.5 meters.
- Fixed close-range selection failures caused by the camera raycast starting inside the NPC hit area.
- Added direct lookup through the synchronized NPC/entity cache before screen-based selection.
- Added an automatic server sync and one-time retry when the NPC entity identity has not reached the client yet.
- Preserved camera-target selection for NPCs outside the close-priority distance.

### Configuration
- Added `Config.Selection.NearPriorityDistance`.
- Added `Config.Selection.SyncRetryDelay`.

## v3.2.1 — Locale, Command & Position Lock Fix

### Türkçe

- `shared/locales.lua` yükleme sırası hatası düzeltildi.
- `PsychofioNPC` tablosu locale dosyası çalışmadan önce güvenli şekilde oluşturulur hale getirildi.
- `PsychofioNPC.Translate` eksik veya hata veriyor olsa bile bildirim sisteminin çökmemesi için güvenli fallback eklendi.
- `npcselect`, `npcanim` ve `npcanimpos` komutlarının locale hatası nedeniyle kesilen çalışma akışı düzeltildi.
- AnimPos açıkken periyodik collision/freeze yenilemesinin editörü bozması engellendi.
- Normal NPC'ler prop gibi bulundukları konuma sabitlenir hale getirildi.
- Animasyon sırasında ped geçici olarak çözülse bile sert anchor sistemiyle başlangıç konumuna kilitlenir hale getirildi.
- Animasyonlu NPC'lerde konum kayması ve fizik kaynaklı sürüklenme azaltıldı.
- Türkçe ve İngilizce locale yükleme akışı çalışma zamanında doğrulandı.

### English

- Fixed the `shared/locales.lua` load-order error.
- Ensured the `PsychofioNPC` table exists before the locale module runs.
- Added a safe notification fallback so a missing or failing `PsychofioNPC.Translate` function cannot crash commands.
- Restored the `npcselect`, `npcanim`, and `npcanimpos` command flow previously interrupted by the locale error.
- Prevented periodic collision/freeze refreshes from breaking the AnimPos editor.
- Managed NPCs now remain fixed to their placed position like persistent props.
- Added a hard anchor that locks animated NPCs to their starting position while still allowing the animation task to play.
- Reduced animation drift and physics-based NPC displacement.
- Runtime-validated both Turkish and English locale loading.


## v3.1.2 — Permission Compatibility Fix

### Türkçe

- Framework yetki uyumluluğu geliştirildi.
- Yeni `auto` yetki modu eklendi.
- QBCore `god/admin` ve ESX `superadmin/admin` desteği eklendi.
- Yetki kaynağını ve reddedilme sebebini gösteren `/psynpcperm` tanılama komutu eklendi.
- Yetki reddi bildirimi tanılama komutuna yönlendirecek şekilde geliştirildi.
- Eski `Config.UsePermissions` ayarıyla geriye dönük uyumluluk korundu.

### English

- Improved framework permission compatibility.
- Added the new `auto` permission mode.
- Added QBCore `god/admin` and ESX `superadmin/admin` support.
- Added the `/psynpcperm` diagnostic command to display the resolved permission source and denial reason.
- Improved permission-denied notifications with a direct diagnostic hint.
- Preserved backward compatibility with `Config.UsePermissions`.

## v3.1.1 — Security and Tebex Release

### Türkçe

- Sunucu kontrollü, süreli ve tek kullanımlık NPC yerleştirme oturumları eklendi.
- Oluşturulan NPC'nin entity sahibi, gerçek koordinatı, yönü, modeli ve routing bucket bilgisi doğrulanır hale getirildi.
- Yakındaki NPC silme ve temizleme işlemlerindeki client koordinatı güveni kaldırıldı.
- NetID, statebag kimliği, veritabanı kaydı, model ve gerçek entity konumu birlikte doğrulanır hale getirildi.
- Yönetilmeyen ambient NPC silme güvenli varsayılan olarak kapatıldı.
- Oluşturma, seçme, düzenleme, animasyon, sync ve silme eventlerine server rate limit eklendi.
- Global NPC limiti için eşzamanlı kayıt kilidi eklendi.
- Request ID tekrarları oyuncu bazında izlenir hale getirildi.
- Animasyon sonuçları yalnızca onaylı entity sahibi veya talep sahibi clienttan kabul edilir hale getirildi.
- SQL sorgu ve güncellemelerine hata yakalama eklendi.
- GPL olarak işaretlenmiş eski AnimPos uyarlaması kaldırılarak bağımsız bir native konum editörü yazıldı.
- Güvenli server exportları ve isteğe bağlı Discord denetim logları eklendi.
- Asset Escrow manifesti, ticari lisans, destek politikası ve kurulum belgeleri eklendi.
- Eski sürüm numarası bildirimleri ve dokümantasyon tutarsızlıkları düzeltildi.

### English

- Added short-lived, single-use, server-controlled NPC placement sessions.
- Added validation for entity ownership, actual coordinates, heading, model, and routing bucket during registration.
- Removed trust in client coordinates from nearby deletion and cleanup operations.
- Net ID, state-bag identity, database row, model, and real entity position are now cross-validated.
- Deletion of unmanaged ambient NPCs is disabled by default.
- Added server rate limits to creation, selection, editing, animation, synchronization, and deletion events.
- Added a concurrency lock around the global NPC limit.
- Duplicate request IDs are now tracked per player.
- Animation results are accepted only from approved entity owners or request clients.
- Added guarded SQL queries and updates.
- Replaced the GPL-labelled legacy AnimPos adaptation with an independently written native position editor.
- Added secure server exports and optional Discord audit logging.
- Added Asset Escrow manifest configuration, commercial license, support policy, and installation documentation.
- Fixed stale version notifications and documentation inconsistencies.
