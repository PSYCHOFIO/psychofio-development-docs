# Psychofio-NPC v3.5.2

Psychofio-NPC; oturum sahibine bağlı NPC oluşturma, konumlandırma, görünüm, isim etiketi, animasyon, bakış yönü ve fotoğraf modu yönetimini tek resource içinde sunar. NPC verisi resource restartına dayanabilmesi için `oxmysql` içinde tutulur; oluşturan oyuncu sunucudan çıktığında NPC ve SQL kaydı tamamen silinir.

## Gereksinimler

- FiveM OneSync
- `oxmysql`
- `Psychofio-Appearance`
- `qb-core` (bu paketle birlikte verilen Psychofio-Appearance sürümünde zorunludur)

## Hızlı kurulum

1. Klasör adlarını değiştirmeden resource dizinine yerleştirin:

```text
resources/[psychofio]/Psychofio-Appearance
resources/[psychofio]/Psychofio-NPC
```

2. `sql/psychofio_npcs.sql` dosyasını veritabanına aktarın. `Config.Database.AutoCreate = true` ise tablo başlangıçta otomatik olarak da oluşturulur.

3. Yetki modu varsayılan olarak `auto` ayarındadır. Script çalışan framework'e
göre QBCore `god/admin` veya ESX `superadmin/admin` yetkisini kabul eder.
Framework yetkisi kullanılmayacaksa `Config.UsePermissions = false` ayarlayın.
Yetki sonucunu oyun içinde `/psynpcperm` komutuyla kontrol edebilirsiniz.

4. Önerilen `server.cfg` sırası:

```cfg
ensure oxmysql
ensure qb-core
ensure Psychofio-Appearance
ensure Psychofio-NPC
```

`qb-core` kullanmıyorsanız veya Appearance kurulumunuz gerektirmiyorsa ilgili satırı kaldırın.

Appearance bağlantısını oyun içinde `/psynpcappearancecheck` komutuyla kontrol
edebilirsiniz. NPC, Appearance resource'una görünüm yazmaz; yalnızca
`GetAppearance` ve `IsFreemodePed` verisini okur.

## Güvenlik varsayılanları

- `Config.UsePermissions = true` ve `Config.PermissionMode = "auto"`
- Her NPC, oturum temizliği için oluşturan oyuncunun o anki server ID'sine bağlanır.
- Varsayılan `ControlMode = "permission"` ile yetkili adminler tüm yönetilen NPC'leri kontrol edebilir. İstenirse `creator` modu kullanılabilir.
- Oluşturan oyuncu sunucudan çıktığında NPC dünyadan ve SQL'den otomatik silinir.
- Yalnızca Psychofio tarafından yönetilen NPC'ler seçilebilir ve silinebilir.
- NPC oluşturma, düzenleme ve silme verileri sunucuda yeniden doğrulanır.
- Yerleştirme işlemleri tek kullanımlık, süreli sunucu oturumu ile açılır.
- Discord denetim logları `server_config.lua` içinden isteğe bağlı açılır.
- Webhook değerini `config.lua` veya NUI dosyalarına yazmayın.

Güvenlik kontrollerini kapatmak satış ve canlı sunucu kullanımı için önerilmez.

## Temel komutlar

```text
/psynpc                 NPC oluşturma ve yerleştirme
/npcselect              Sunucudan en yakın yönetilen NPC'yi seçer
/npcselect aim          Nişangâhla etkileşimli NPC seçimi açar
/npcdelete              En yakın NPC'yi önce SQL'den, sonra dünyadan siler
/npcclear               Yakındaki NPC'leri SQL doğrulamasıyla temizler
/npctag <isim>          Seçili NPC'nin adını değiştirir
/npcanim <preset>       Animasyon uygular
/npcanim stop           Animasyonu durdurur
/npcanimpos             Animasyonlu NPC'nin konumunu hassas ayarlar
/npcanims [arama]       Animasyon listesini F8 konsoluna yazar
/npclook me|clear|x y z NPC'nin bakış hedefini ayarlar
/npcturn me|heading 180 NPC yönünü ayarlar
/photomode              NPC fotoğraf modunu açar veya kapatır
/npccoords              Seçili NPC koordinatını gösterir
/npchelp                Yardım komutlarını gösterir
```

Sunucu yönetim ve diagnostic komutları:

```text
/npcdebug
/npcanimreload
/psynpcperm             Yetki kaynağını ve sonucu gösterir
```

Komut adlarının çoğu `Config.Commands` bölümünden değiştirilebilir.

## Dil ve özel animasyonlar

- Tek `Config.Language` ayarı bildirimleri, NUI'yi, AnimPos yardım panelini,
  komut yardımlarını ve server/F8 durum metinlerini birlikte `tr` veya `en` yapar.
- Sunucuya eklenen özel YCD animasyonlarının mevcut Lua/JSON listeleri ve
  resource manifestleri otomatik taranır; alıcının animasyonları config içine
  kopyalaması gerekmez.
- RPEmotes/DPEmotes biçimindeki `Prop`, `PropBone`, `PropPlacement`,
  `SecondProp` alanları korunur; objeler animasyonla birlikte bağlanır ve
  animasyon/NPC temizlenince silinir.

Ayrıntılı örnekler için `ANIMATION_INTEGRATION_TR.md` dosyasına bakın.

## AnimPos kontrolleri

```text
W / A / S / D      Hareket
Q / Z              Yukarı / aşağı
Mouse tekerleği    Yönü döndürme
Left Shift         Hızlı hareket
Left Ctrl          Hassas hareket
ENTER              Kaydet
BACKSPACE          İptal
```

## Görünüm entegrasyonu

Resource, NPC oluşturulurken görünümü şu export ile alır:

```lua
exports['Psychofio-Appearance']:GetAppearance(ped)
```

Appearance resource adını değiştirdiyseniz `Config.PreferredAppearanceResource` ve `Config.AppearanceResources` alanlarını güncelleyin.

## Güvenli server exportları

Başka bir sunucu scriptinden yerleştirme menüsü açmak için:

```lua
exports['Psychofio-NPC']:OpenPlacementForPlayer(playerSource)
exports['Psychofio-NPC']:OpenCopyPlacementForPlayer(playerSource, npcId)
```

Exportlar hedef oyuncunun yapılandırılmış framework yetkisini, SQL durumunu ve global NPC limitini doğrular.

## Özel animasyon ekleme

Detaylar ve JSON/export örnekleri için `ANIMATION_INTEGRATION_TR.md` dosyasını okuyun.

## Güncelleme notu

Bu sürüm `psychofio_npcs` tablosuna `owner_source` ve `owner_identifier` alanlarını ekler. Resource otomatik migration yapar; veritabanı kullanıcısında `ALTER` yetkisi yoksa `sql/upgrade_3_3_0.sql` dosyasını bir kez çalıştırın. Eski sürümden kalan sahipsiz kayıtlar başlangıç sırasında silinir. Güncellemeden önce resource klasörü ile veritabanının yedeğini alın.


## v3.2.3 Restart ve `/npcselect` düzeltmesi

- Resource yeniden başlatıldığında SQL NPC'leri doğrudan yeniden spawn edilmez. Önce aynı model/konumdaki mevcut Psychofio entity sahiplenilir.
- Aynı SQL kaydının fazladan ghost kopyaları NetID bazında temizlenir.
- `/npcselect`, client raycast yerine sunucudaki kalıcı NPC listesinden oyuncuya en yakın yönetilen NPC'yi seçer.
- Seçim mesafesi `Config.Selection.SelectDistance` ile, restart uzlaştırma ayarları `Config.RestartReconciliation` ile yönetilir.
- Eski fazlalıkları SQL kayıtlarını silmeden manuel temizlemek için `/npcdedupe` kullanılabilir.

## v3.2.2 NPC Seçim Davranışı

`/npcselect`, oyuncunun 3,5 metre içerisindeki en yakın Psychofio NPC'sini önce seçer. Yakında NPC yoksa kamera merkezindeki yönetilen NPC aranır. Entity kimliği henüz clienta ulaşmadıysa script sunucudan senkronizasyon isteyip seçimi bir kez otomatik tekrarlar. Mesafeler `Config.Selection.NearPriorityDistance` ve `SyncRetryDelay` ile değiştirilebilir.

## Etkileşimli NPC Seçimi

Normal `/npcselect`, en yakın yönetilen NPC'yi sunucudaki runtime kayıtları ile hafif SQL kimlik/konum listesini birleştirerek seçer. Server entity handle'ı OneSync scope geçişinde çözülemese bile kalıcı ID ve kayıtlı koordinat kullanılır. Nişangâhlı seçim istenirse `/npcselect aim` kullanılır; NPC kırmızı çizgiyle vurgulanır, Enter veya sol tıkla seçilir, Backspace veya Esc ile iptal edilir. `/npcselect nearest` normal seçim yolunun açık adıdır.

Seçimden sonraki etiket, bakış, dönüş, animasyon ve AnimPos komutları kalıcı
NPC ID'sini NetID, model ve koordinatla birlikte servera gönderir. Server entity
handle geçici olarak scope dışında kalırsa SQL güncellemesi serverda yapılır ve
görsel işlem doğrulanmış kimlik paketiyle entityyi gören clientlara uygulanır.
