# Psychofio-NPC v3.5.2 Sales Finalization Test Report

- The legacy server permission path and all related configuration were removed.
- Framework authorization remains available through QBCore and ESX.
- Customer runtime archives contain no Markdown files; public documentation is
  maintained as a separate GitHub-ready bundle.

- Delayed static discovery no longer removes runtime export registrations from
  the same animation resource.
- Rejected export collisions are not retained and cannot override protected
  config entries during a future registry rebuild.
- Customer sales contents exclude test harnesses and internal test reports.
- Runtime source, customer documentation, SQL, support, third-party notices,
  commercial terms, and editable configuration remain included.

# Psychofio-NPC v3.5.0 Zero-Config Animation / Full EN Test Report

- Animation mock imported a non-standard manifest-declared Lua list without
  any NPC config entry.
- A second resource with no animation-related name was imported through a
  standard animation-list path.
- Runtime resource-start scanning remains enabled for animation packs started
  after Psychofio-NPC.
- `Config.CustomAnimations` and the second language setting were removed from
  buyer configuration.
- `Config.Language = "en"` controls client/server notifications, NUI, native
  help, command help, F8 output, and localized server status messages.
- 166 representative user-facing and console messages passed the English
  coverage test with no Turkish phrase remaining.
- Existing management, SQL-first deletion, selection, prop, and appearance
  protections remained green.

# Psychofio-NPC v3.4.0 Language / Custom Animation / Prop Test Report

- `Config.Language` and `Config.MenuLanguage` independently resolve script and
  menu language to `tr` or `en`.
- Placement, selection key labels, and the native AnimPos help panel have
  complete Turkish and English text paths.
- `Config.CustomAnimations` seeds the authoritative server registry.
- Explicit non-standard resource paths are discovered through
  `Config.AnimationDiscovery.ResourceFiles`.
- Static Lua discovery accepts both positional RPEmotes/DPEmotes entries and
  named `dictionary`/`animation` entries without executing external code.
- Loop + moving options normalize to flag `49`; primary and secondary prop
  model, bone, position, and rotation data survive registry normalization.
- String prop model names and numeric model hashes are accepted.
- Prop cleanup covers animation replacement, stop, NPC removal, resource stop,
  and streamed entity disappearance.
- The feature mock, management scope mock, PowerShell regression suite, and
  all 21 Lua parser checks passed.
- Psychofio-Appearance source files were not modified.

# Psychofio-NPC v3.3.7 Selected Management Test Report

- Selected management payloads now include persistent NPC ID, NetID, model,
  and coordinates.
- The shared server validator resolves selected NPCs through the merged runtime
  and SQL identity list.
- When the server ped handle is unavailable, permissions, model, coordinates,
  player distance, and routing bucket are still server-validated.
- Tag, look, heading, AnimPos, and animation updates passed the actual server
  event-handler mock with no server-side NPC handle.
- Visual fallback commands are broadcast with a server-built identity payload;
  clients require matching persistent ID or NetID before applying them.

- Selection, single delete, and nearby clear no longer require a live
  server-side ped handle.
- Runtime NPC records are merged with a lightweight SQL identity/position query.
- Persistent coordinates and routing-bucket ownership are used when OneSync
  temporarily moves the entity outside server scope.
- Registration acceptance caches the persistent ID even when the final ped has
  not returned to the creating client's scope yet.
- Identity deletion is broadcast with ID, model, coordinates, and NetID before
  entity/cache removal.
- The actual server command handlers passed a Fengari runtime mock with an SQL
  NPC that deliberately had no server-side entity handle.

- `/npcdelete` and `/npcclear` now choose managed NPCs on the server.
- SQL row absence is verified before the world entity and runtime cache are deleted.
- A failed SQL deletion leaves the entity intact and reports the failure to the client.
- Plain `/npcselect` uses server-authoritative nearest selection; `/npcselect aim`
  remains available as the optional interactive mode.
- The default permission control mode allows every authorized admin to manage
  Psychofio NPCs while creator identity remains available for disconnect cleanup.
- The local regression model verified that a failed SQL delete preserves the
  entity and a successful delete cannot return after a simulated restart.

- Appearance source is treated as read-only; NPC calls only `GetAppearance`
  and `IsFreemodePed`.
- Component/prop application runs before the full freemode face pipeline.
- Explicit and statebag appearance paths require a verified managed NPC identity.
- Legacy runtime permission mutation is absent.
- Static export audit found exactly two Appearance calls: `GetAppearance` and
  `IsFreemodePed`; no Appearance write/menu export is called.
- Historical v3.3.7 manifest references and version alignment passed.
- The 42-file Appearance source matched the existing v1.4.3 release archive
  file-for-file; no Appearance file was modified.
- Interactive selection forwards unresolved network NPCs to the authoritative
  server instead of rejecting them during statebag replication.
- Identity resolution returns a response on rate-limit rejection and accepts a
  server-validated persistent-ID hint.

- All 12 statebag keys use the private `psychofioNpc:*` namespace.
- Appearance adapter, fallback, core apply and explicit event paths reject player peds.
- Server registration rejects every connected player's ped.
- Server resolve/configure/state/delete boundaries reject stale NetIDs resolving to a player.
- Client identity, weapon, look, position, heading, animation, collision and delete
  boundaries reject player peds.
- Missing face-feature fields remain unchanged instead of being forced to `-1`.
- Missing hair, eye-color and tattoo fields remain unchanged in partial payloads.
- 19 resource Lua files, the Lua control-scope test harness, and the NUI
  JavaScript passed parser validation.

# v3.3.1 Selection/Ownership Fix

- Client owner pre-filter removed.
- Selection confirmation forced through server identity resolver.
- Ownership is server-ID authoritative for session NPCs.

# Psychofio-NPC v3.3.1 Selection and Ownership Test Report

## Completed static/runtime checks

- 19 Lua files parsed successfully with `texluac -p`.
- NUI JavaScript passed `node --check`.
- Owner ID 11 can control a runtime NPC owned by ID 11.
- Owner ID 22 is rejected for an NPC owned by ID 11.
- Matching server ID with a different license identifier is rejected.
- Disconnect cleanup is mandatory and cannot be disabled from config.
- Disconnect cleanup removed only owner ID 11's two NPCs from runtime and mocked SQL; owner ID 22's NPC remained.
- Ownership database validation passed for matching and mismatching server-ID/license combinations.
- Selected tag, look, turn, animation, and AnimPos events remain routed through the shared owner-validating `validateSelectedEntity` function.
- Nearby delete and clear paths validate ownership before SQL/entity deletion.
- Copy-placement export validates the requesting player's ownership.
- Startup loading filters offline-owner and legacy unowned database rows before spawning.

## Environment limitation

A live FiveM/OneSync server was not available. Final acceptance should verify two simultaneous players, disconnect cleanup, resource `ensure`, and source-ID reuse behavior on a staging server.

# Psychofio-NPC v3.2.3 — Test Report

## Automated checks completed

- All 18 Lua/manifest files were parsed successfully with LuaTeX `loadfile` syntax validation.
- `web/app.js` passed Node.js syntax validation.
- A mocked OneSync restart test passed: one SQL row with two existing matching entities adopted one entity, deleted the duplicate, and spawned zero new peds.
- A second simulated resource restart adopted the surviving entity again and spawned zero new peds.
- A mocked server selection test passed: `/npcselect` server logic selected the closest managed NPC and returned its persistent ID and NetID.
- The client command registration, server request event, and client response event were verified to exist.
- No call to the old startup `PurgeTaggedNPCEntities()` flow remains in `server/main.lua`.
- Historical v3.3.1 build: `fxmanifest.lua`, shared version, and the user-facing
  fallback version were aligned at the time of that release.

## Live FiveM tests still required

A real FiveM/OneSync/oxmysql runtime is not available in this build environment. Before publishing, verify on a staging server:

1. Place one NPC, run `ensure Psychofio-NPC` repeatedly, and confirm the ped count does not increase.
2. Stand next to a managed NPC and run `/npcselect`; confirm the notification includes its persistent ID.
3. Run `/npcanim` and `/npcanimpos` after selection.
4. Test two legitimate SQL NPC records using the same model and exact coordinates; both should remain while only extra entity copies are removed.
5. Test a player in a different routing bucket; `/npcselect` must not select an NPC outside the player's bucket.
6. Test resource stop/start with connected players and after a full server restart.

## v3.2.4 Interactive Selection Checks

- Prop-style raycast selection module included in the manifest.
- Enter and left-click confirmation controls are registered.
- Backspace and Escape cancellation controls are registered.
- Red outline, marker, and camera line are cleared on cancel/resource stop.
- `/npcselect` starts interactive mode; `/npcselect nearest` preserves the previous fallback.
- Final identity commit still uses the existing managed-NPC resolution and validation flow.
