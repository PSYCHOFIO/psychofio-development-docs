# Psychofio-NPC Commercial License

Copyright © 2026 Psychofio Development. All rights reserved.

Purchase grants the customer a limited, non-exclusive, non-transferable license to install and use this resource on FiveM servers owned or legitimately administered by the customer, subject to the applicable Tebex and Cfx.re terms.

The customer may edit files intentionally left open through the Asset Escrow configuration. The customer may not resell, redistribute, sublicense, leak, share, publish, decrypt, reverse engineer, remove ownership notices from, or provide the protected resource or substantial portions of it to third parties.

A contractor may access the resource only when required to work on the licensed customer's server and must not retain or reuse a copy afterward. The customer remains responsible for that access.

Dependencies and external platforms remain subject to their own licenses and terms. No ownership of FiveM, Cfx.re, Tebex, oxmysql, or Psychofio-Appearance is claimed by this license.

The software is provided without a guarantee that it will be compatible with every modified server environment or third-party resource. Mandatory consumer rights under applicable law are not excluded. Refunds and disputes are handled under the storefront terms and applicable law.

Violation of these terms terminates the granted usage rights.
