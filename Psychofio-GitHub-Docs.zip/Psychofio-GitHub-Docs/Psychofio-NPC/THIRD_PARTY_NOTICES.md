# Third-Party Notices

No third-party source code is intentionally bundled in this release.

Runtime dependencies such as FiveM/Cfx.re, oxmysql, and Psychofio-Appearance remain subject to their respective licenses and terms.
