# Psychofio-NPC v3.5.2

# START HERE — Psychofio-NPC v3.5.2

## Türkçe

1. Resource klasör adını `Psychofio-NPC` olarak koruyun.
2. `oxmysql`, `Psychofio-Appearance` ve OneSync'in çalıştığını doğrulayın.
3. `sql/psychofio_npcs.sql` dosyasını içe aktarın.
4. Varsayılan `auto` yetki modu çalışan framework'e göre QBCore admin/god veya ESX admin/superadmin yetkisini kabul eder. Framework yetkisi istenmiyorsa `Config.UsePermissions = false` ayarlayın.
5. `config.lua` içindeki özellikleri, tek `Config.Language` dil seçeneğini ve
   `server_config.lua` içindeki sunucuya özel log ayarlarını düzenleyin.
6. Resource'u `ensure Psychofio-NPC` ile başlatın.
7. `/psynpcperm` ve `/psynpcappearancecheck` ile bağlantıları doğrulayın, ardından yetkili bir hesapla ilk kabul testini `/psynpc`, `/npcselect`, `/npcdelete` ve sunucu restartı üzerinden yapın.

Asset Escrow entitlement hatası alırsanız `ASSET_ESCROW.md` dosyasını okuyun.

## English

1. Keep the resource folder name as `Psychofio-NPC`.
2. Confirm that OneSync, `oxmysql`, and `Psychofio-Appearance` are running.
3. Import `sql/psychofio_npcs.sql`.
4. The default `auto` permission mode accepts QBCore admin/god or ESX admin/superadmin according to the running framework. Set `Config.UsePermissions = false` when framework permissions are not wanted.
5. Edit public options, the single `Config.Language` setting, and
   server-only audit settings in `server_config.lua`.
6. Start the resource with `ensure Psychofio-NPC`.
7. Verify the result with `/psynpcperm` and `/psynpcappearancecheck`, then run the first acceptance test with an authorized account using `/psynpc`, `/npcselect`, `/npcdelete`, and a full server restart.

Read `ASSET_ESCROW.md` when an entitlement error is shown.

## NPC Select Mode

Use `/npcselect` to select the nearest managed NPC through the server. For crosshair selection use `/npcselect aim`, then press Enter or left click. Backspace or Escape cancels aim mode.

## v3.3.0 Session Ownership

> **Güncelleme uyarısı:** Eski sahipsiz NPC kayıtları ilk başlangıçta silinir. Güncellemeden önce `psychofio_npcs` tablosunun yedeğini alın.

Each NPC retains its creator server ID for disconnect cleanup. By default, every authorized Psychofio-NPC admin can select and modify managed NPCs; `Config.Ownership.ControlMode = "creator"` restores creator-only control. When the creator disconnects, the NPC is deleted from the game and database. Run `sql/upgrade_3_3_0.sql` manually only when automatic database migration cannot use `ALTER TABLE`.
