# Psychofio Development — Support Policy

## Included support

- Installation guidance for the documented requirements
- Reproducible bugs in the unmodified current release
- Configuration questions for files intentionally left editable
- Asset entitlement troubleshooting guidance within the seller's control

## Not included

- Custom feature development or server-specific rewrites
- Conflicts caused by modified protected files, renamed dependencies, leaked copies, or unsupported forks
- General FiveM, framework, database, hosting, or third-party resource administration
- Recovery of data when no backup exists

## Before requesting support

Provide the purchase reference, server artifact version, dependency versions, complete console error, reproduction steps, and relevant configuration with secrets removed. Never send database passwords, server keys, webhook URLs, or API tokens.
