# Psychofio-NPC v3.5.2

Psychofio-NPC provides session-owned NPC creation, placement, appearance, name tags, animations, look targets, and photo-mode controls in one resource. NPC data is stored with `oxmysql` to survive a resource restart, but the NPC and its SQL row are deleted when the creator disconnects.

## Requirements

- FiveM OneSync
- `oxmysql`
- `Psychofio-Appearance`
- `qb-core` (required by the bundled Psychofio-Appearance build)

## Quick installation

1. Keep the resource folder names unchanged:

```text
resources/[psychofio]/Psychofio-Appearance
resources/[psychofio]/Psychofio-NPC
```

2. Import `sql/psychofio_npcs.sql`. The table can also be created automatically when `Config.Database.AutoCreate = true`.

3. The default permission mode is `auto`. The resource accepts QBCore
`god/admin` or ESX `superadmin/admin`, depending on the running framework.
Set `Config.UsePermissions = false` when framework permissions are not wanted.
Use `/psynpcperm` in game to inspect the resolved permission source.

4. Recommended `server.cfg` order:

```cfg
ensure oxmysql
ensure qb-core
ensure Psychofio-Appearance
ensure Psychofio-NPC
```

Remove `qb-core` when your server or Appearance installation does not require it.
Use `/psynpcappearancecheck` in game to verify the read-only Appearance
connection and the captured face schema.

## Secure defaults

- `Config.UsePermissions = true` and `Config.PermissionMode = "auto"`
- Every NPC is bound to the creator's current server ID for session cleanup.
- With the default `ControlMode = "permission"`, authorized admins can control every managed NPC. Set it to `creator` to restrict control to the creator.
- When the creator disconnects, their NPCs are removed from the world and SQL automatically.
- Only NPCs managed by Psychofio can be selected or deleted by default.
- Creation, editing, and deletion payloads are revalidated by the server.
- Placement uses a short-lived, one-time server session.
- Optional Discord audit logs are configured only in `server_config.lua`.
- Never place webhook values in `config.lua` or NUI files.


## Main commands

```text
/psynpc                 Create and place an NPC
/npcselect              Select the nearest server-managed NPC
/npcselect aim          Open interactive crosshair selection
/npcdelete              Delete the nearest NPC from SQL, then the world
/npcclear               Clear nearby NPCs with SQL verification
/npctag <name>          Rename the selected NPC
/npcanim <preset>       Apply an animation
/npcanim stop           Stop the current animation
/npcanimpos             Precisely reposition an animated NPC
/npcanims [search]      Print available animations to the F8 console
/npclook me|clear|x y z Set the NPC look target
/npcturn me|heading 180 Change the NPC heading
/photomode              Toggle NPC photo mode
/npccoords              Display selected NPC coordinates
/npchelp                Show command help
```

Server management and diagnostic commands:

```text
/npcdebug
/npcanimreload
/psynpcperm             Shows the resolved permission source and result
```

Most command names can be changed under `Config.Commands`.

## Languages and custom animations

- A single `Config.Language` setting switches notifications, NUI, AnimPos
  instructions, command help, and server/F8 status text between `tr` and `en`.
- Existing Lua/JSON animation lists and resource manifests are scanned
  automatically for custom YCD animations; buyers do not paste animations into
  the NPC config.
- RPEmotes/DPEmotes fields such as `Prop`, `PropBone`, `PropPlacement`, and
  `SecondProp` are preserved. Objects are attached with the animation and
  deleted when the animation or NPC is cleaned up.

See `ANIMATION_INTEGRATION_EN.md` for complete examples.

## AnimPos controls

```text
W / A / S / D      Move
Q / Z              Move up / down
Mouse wheel        Rotate heading
Left Shift         Fast movement
Left Ctrl          Precision movement
ENTER              Save
BACKSPACE          Cancel
```

## Appearance integration

The resource captures an NPC appearance through:

```lua
exports['Psychofio-Appearance']:GetAppearance(ped)
```

When changing the Appearance resource folder name, update `Config.PreferredAppearanceResource` and `Config.AppearanceResources`.

## Secure server exports

To open placement from another server resource:

```lua
exports['Psychofio-NPC']:OpenPlacementForPlayer(playerSource)
exports['Psychofio-NPC']:OpenCopyPlacementForPlayer(playerSource, npcId)
```

The exports validate the target player's configured framework permission, database readiness, and global NPC limit.

## Custom animations

Read `ANIMATION_INTEGRATION_EN.md` for JSON discovery and server export examples.

## Upgrade note

This release adds `owner_source` and `owner_identifier` to the `psychofio_npcs` table. The resource performs the migration automatically; when the database user does not have `ALTER` permission, run `sql/upgrade_3_3_0.sql` once. Legacy rows without an active session owner are deleted during startup. Back up the resource and database before updating.


## v3.2.3 Restart and `/npcselect` fix

- SQL NPCs are no longer spawned unconditionally after a resource restart. Existing Psychofio entities matching the saved model and position are adopted first.
- Extra ghost copies of the same persistent record are removed by NetID.
- `/npcselect` now asks the server-managed persistent NPC registry for the nearest controlled NPC instead of depending on client raycast timing.
- Selection distance is configured with `Config.Selection.SelectDistance`; restart reconciliation is configured under `Config.RestartReconciliation`.
- Use `/npcdedupe` to manually remove existing extra ghost entities without deleting SQL records.

## v3.2.2 NPC Selection Behavior

`/npcselect` first selects the nearest Psychofio-managed NPC within 3.5 meters. When no NPC is nearby, it falls back to the managed NPC closest to the camera center. If the entity identity has not reached the client yet, the resource requests a server sync and retries once. Adjust this with `Config.Selection.NearPriorityDistance` and `SyncRetryDelay`.

## Interactive NPC Selection

Plain `/npcselect` merges the server runtime registry with a lightweight SQL identity/position list. A temporary OneSync entity-scope loss therefore cannot hide a managed NPC from selection. Use `/npcselect aim` for crosshair mode; confirm with Enter or left click and cancel with Backspace or Escape. `/npcselect nearest` is an explicit alias for the default path.

Post-selection tag, look, turn, animation, and AnimPos commands send the
persistent NPC ID together with NetID, model, and coordinates. If the server
entity handle is temporarily outside scope, SQL is still updated on the server
and the verified visual action is applied by clients that can see the entity.
