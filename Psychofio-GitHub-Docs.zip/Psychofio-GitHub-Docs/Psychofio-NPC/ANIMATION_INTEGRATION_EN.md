# Psychofio-NPC custom animation integration

## Normal setup: no action required

Psychofio-NPC scans running resource manifests and common animation-list paths
automatically. When RPEmotes, DPEmotes, Scully, or a similar menu exposes a
readable Lua/JSON list, its animations and prop options are imported at startup.
The JSON/export methods below are advanced compatibility paths for encrypted or
unusual providers only.

## Automatic JSON discovery

Place `psychofio_npc_anims.json` in the root of the custom animation resource:

```text
my-custom-anims/
├── fxmanifest.lua
├── psychofio_npc_anims.json
└── stream/
    └── custom_anims.ycd
```

Example:

```json
{
  "animations": {
    "customwave": {
      "type": "anim",
      "dict": "custom_anim_dict",
      "clip": "custom_wave_clip",
      "flag": 49,
      "duration": -1
    },
    "guardpose": {
      "type": "scenario",
      "scenario": "WORLD_HUMAN_GUARD_STAND"
    }
  }
}
```

For a custom path, add this metadata to the animation resource's `fxmanifest.lua`:

```lua
psychofio_npc_animation_file 'data/my_animations.json'
```

The `psychofio_npc_anim_file` metadata name is also supported.

## Using an existing server-side Lua animation list

Psychofio-NPC tries common animation-list paths in every running resource. It
also scans Lua/JSON paths declared in manifests when the resource or filename
contains an animation marker such as `rpemotes`, `dpemotes`, `scully`, `emote`,
`animation`, `anims`, `dance`, or `pose`. Buyers do not paste animations into
the NPC config.

Both the positional RPEmotes/DPEmotes format:

```lua
["burger"] = {
    "anim@heists@box_carry@",
    "idle",
    "Burger",
    AnimationOptions = {
        EmoteLoop = true,
        EmoteMoving = true,
        Prop = "prop_cs_burger_01",
        PropBone = 60309,
        PropPlacement = { 0.05, 0.01, -0.02, 10.0, 20.0, 30.0 },
        SecondProp = "prop_food_bs_cups02",
        SecondPropBone = 28422,
        SecondPropPlacement = { 0.01, 0.02, 0.03, 0.0, 0.0, 90.0 }
    }
}
```

and named fields such as `dict/clip` or `dictionary/animation` are supported.
The scanner never executes external resource code; it only reads static table
data. New resources are imported automatically when they start; use
`/npcanimreload` only when a manual refresh is desired. Each client creates the
prop locally, attaches it to the configured ped bone, and deletes it when the
animation is stopped/replaced or the NPC is removed.

## Registering through server exports

```lua
exports['Psychofio-NPC']:RegisterAnimation('customwave', {
    type = 'anim',
    dict = 'custom_anim_dict',
    clip = 'custom_wave_clip',
    flag = 49,
    duration = -1
})
```

Bulk registration:

```lua
exports['Psychofio-NPC']:RegisterAnimations({
    customwave = {
        type = 'anim',
        dict = 'custom_anim_dict',
        clip = 'custom_wave_clip',
        flag = 49,
        duration = -1
    }
})
```

Start `Psychofio-NPC` before any resource that registers animations through these exports.
