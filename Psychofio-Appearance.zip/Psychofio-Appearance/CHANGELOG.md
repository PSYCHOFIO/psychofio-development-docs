# Changelog

## 1.4.3 — Ped Model Code Input

### Added

- Replaced the default preset-only ped selector with model name/hash input.
- Added support for GTA model names, decimal hashes, and hexadecimal hashes.
- Kept optional preset cards behind `Config.PedSelection.showPresetModels`.

### Security and reliability

- Rejects missing, oversized, invalid, non-CD-image, and non-ped models before
  changing the player model.
- Loads the requested model before changing history, so a failed request does
  not create an empty undo entry.
- Verifies unlisted saved model hashes against the active OneSync player ped.
- Regular clothing and wardrobe sessions cannot inject a different ped model.
- Preserves valid selected custom ped models across save and reconnect.

## 1.4.2 — Commercial Release

- Removed internal development and reference branding from customer-facing
  comments and documentation.
- Consolidated customer documentation for Cfx.re Asset Escrow delivery.
- Preserved the optimized 1.4.1 runtime, database schema, and appearance JSON.

## 1.4.1 — Safe Optimization Pass

- Cached GTA head-overlay and hair-color limits for the resource lifetime.
- Removed repeated face-state normalization while preserving native order and
  head-blend restoration.
- Cached tattoo catalogs by ped model and language.
- Replaced nested selected-tattoo scans with lookup sets.
- Reduced duplicate component/prop limit queries, state copies, and history
  fingerprint work.
- Reduced NUI selector work and protected range/save queues against stale
  session responses and double-click races.
- Preserved the 1.4.0 face engine, 70 ms debounce, save flush, 20 face feature
  writes, and 13 overlay writes.

## 1.4.0 — Full Face Engine v2

- Replaced fragmented updates with one authoritative face draft for head blend,
  all 20 features, and all 13 supported GTA overlays.
- Removed the repeating head-blend rebuild that could erase beard, eyebrow, or
  morph changes.
- Explicitly converted head-blend, face-feature, and overlay values to Lua
  floats before native calls.
- Serialized all face groups through a latest-state queue.
- Flushed pending face edits before save.
- Added numeric/string-key and legacy overlay normalization.
- Restored features and overlays once after a head-blend rebuild.

## 1.3.4 — Player Editor State Isolation

- External ped capture/application no longer overwrites the local editor state.
- Face reapplication is limited to the current local player ped.
- Removed obsolete cross-resource installation and schema references.

## 1.3.3 — Face Core Stabilization

- Kept face features and overlays in the active editor state instead of
  rebuilding from transient native reads after every rapid request.
- Reapplied freemode head blend, overlays, opacity, and color after delayed
  framework/model activity while the editor remained open.
- Added runtime face diagnostics and a neutral editor pose.

## 1.3.2 — Beard Button Stability

- Represented an empty beard as `-1`, preserving style `0` as a valid style.
- Fixed the first plus-button press skipping or corrupting style `0`.
- Serialized rapid overlay requests.
- Preserved beard opacity and color while changing styles.
- Fixed clearing a beard and selecting the first style again.
- Added server validation for the normalized `-1` empty-overlay value.

## 1.3.1 — Ped, Outfit, Tattoo, and Beard Fixes

- Added a config allowlist-based Ped Selection tab to `/pedmenu`.
- Added model persistence for approved custom ped models.
- Expanded the tattoo catalog to 869 entries across torso, arms, legs, head,
  and hair zones.
- Added tattoo search, zone filtering, and per-zone cameras.
- Fixed the final outfit card remaining after the last saved outfit was deleted.
- Fixed beard style, opacity, and color resets.
- Outfit images now accept only Discord attachment/CDN URLs.
- Non-freemode peds disable incompatible face, beard, and tattoo controls.

## 1.3.0 — Asset Escrow, Security, and Player Experience

### Packaging

- Added Cfx.re Asset Escrow metadata and explicit editable-file exclusions.
- Added commercial license, start guide, support policy, and entitlement
  troubleshooting.
- Added OneSync as a runtime dependency.
- Expanded third-party notices with required MIT text.
- No custom IP lock, remote loader, obfuscator, or manual serial was added.

### Security

- Added expiring server-issued editor tokens bound to player and context.
- Added server-side distance, access, mode, and allowed-field enforcement.
- Added validation for components, props, palettes, head blend, overlays, hair,
  eyes, and tattoo IDs.
- Added operation cooldowns, outfit locks, and restricted legacy external
  client integrations.
- Added payment refunds when appearance persistence fails.
- Added optional Discord logs for denials, saves, and outfit actions.

### Player experience and database

- Added Undo/Redo and original-appearance comparison.
- Added outfit favorites, folders, search, and five quick slots.
- Added physical barber and tattoo shop support.
- Added shop-specific availability and change-based pricing.
- Added `favorite`, `folder`, and `quick_slot` outfit fields with migration.
- Added secure `OpenMenuForPlayer` and `OpenWardrobeForPlayer` exports.

## 1.2.1 — Outfit NUI Reliability

- Replaced the browser `confirm()` dialog with a FiveM-compatible custom modal.
- Added duplicate-request protection to delete, save, and rename actions.
- Updated outfit cards directly from the server response.
- Added full-size, aspect-preserving outfit image preview.
- Fixed Escape and backdrop behavior for modals.

## 1.2.0 — Psychofio Branding and Interface Refresh

- Renamed the resource to `Psychofio-Appearance`.
- Moved events, callbacks, export examples, permissions, and SQL tables into the
  Psychofio namespace.
- Rebuilt the interface with the Psychofio black, red, and off-white palette.
- Updated the logo, preview cards, buttons, sliders, camera rail, and lighting.
- Removed obsolete brand files and references.

## 1.1.7 — Clothing Store Location and Prompt

- Corrected the Hawick store to
  `vector4(121.08, -225.77, 54.56, 338.58)`.
- Kept E-key interaction even when `qb-target` is active.
- Added visible 3D and GTA help prompts near the store.
- Made interaction distance configurable per store.

## 1.1.6 — Clothing Store E Interaction

- Added the Del Perro/Suburban store at
  `vector3(-1194.950, -772.629, 17.325)`.
- Added direct E-key interaction, prompt, heading, and optional marker settings.
- Limited the store view to clothing, outfits, and accessories.

## 1.1.5 — Tattoo Command Separation

- Added `/tattoo [id]` for the Tattoos tab only.
- Removed tattoos from `/appearance`.
- Blocked tattoo changes through NUI manipulation in appearance mode.
- Kept tattoos available in `/pedmenu` and initial creation.
- Hid outfit-save controls in tattoo-only mode.

## 1.1.4 — Command Modes and Freemode Compatibility

- Removed Face & Hair from `/appearance`.
- Blocked face, head blend, hair, beard, overlay, and eye changes in that mode.
- Kept `/barber` limited to hair and beard.
- Kept `/pedmenu` as the full character editor.
- Moved freemode compatibility checks to `Config.FreemodeModels`.
- Fixed custom freemode/EUP models being incorrectly locked.

## 1.1.3 — Character Function Hotfix

- Restored `applyForCharacter`, `resetCharacterForCreation`, and
  `forceCharacterFreemode`.
- Fixed the nil-function error that blocked saved appearance on player load.
- Restored freemode preparation for creation and editor commands.

## 1.1.2 — Static Pose and Mouse Parallax

- Removed hard entity freeze from the editor pose.
- Improved animation and legacy-freeze cleanup when closing.
- Restored mouse-driven 3D panel parallax.
- Restored rounded panel corners.
- Updated body, face, torso, legs, and feet camera presets.

## 1.1.1 — Pose Lock and 3D UI

- Stabilized the player ped at the editor position without restarting animation
  on every slider callback.
- Prevented delayed cleanup threads from unlocking a newly opened editor.
- Added layered 3D depth effects to the menu, cards, and buttons.
- Refreshed sidebar, camera, rotation, reset, close, save, and slider icons.

## 1.1.0 — Slider and Outfit Scope Rewrite

- Rewrote slider dragging so active controls are not recreated by NUI replies.
- Added editable numeric inputs for models, textures, hair, beard, and face.
- Removed component 0 from clothing.
- Fixed component 10 labeling.
- Serialized hair and beard requests.
- Added a selectable fallback when clipboard copy fails.
- Limited outfit/share codes to wearable components and props.
- Strengthened routing bucket, conceal, alpha, and voice cleanup.

## 1.0.9 — Overlay and Clipboard Reliability

- Rebuilt range controls without rerendering during drag.
- Fixed hair and beard request races.
- Restored visible beard opacity when selecting a beard style.
- Removed face/head from clothing.
- Prevented face, hair, beard, makeup, eyes, and tattoos from entering outfit
  share codes.
- Added native, Clipboard API, and CEF clipboard fallbacks.

## 1.0.8 — Rotation, Cameras, and Tattoos

- Moved rotation controls into a compact panel-side cluster.
- Shifted camera presets to improve character framing.
- Added a gender-aware base tattoo catalog and tattoo camera focus.
- Recreated a clean freemode ped for new character creation.
- Cleared client appearance state on QBCore player unload.

## 1.0.7 — Editor Mode Separation

- Improved character framing around the rotation controls.
- Removed Face & Hair from `/appearance`.
- Added `/barber [id]` for hair and beard only.
- Kept `/pedmenu [id]` as the full face editor.
- Restricted NUI/client callbacks by active editor mode.

## 1.0.6 — Camera Pool and Transition Safety

- Prevented recreation of the active camera preset on slider/clothing changes.
- Fixed rapid-transition threads deleting the newest camera.
- Added a camera pool and safe cleanup.
- Added return-to-main-camera behavior when selecting the active rail button.

## 1.0.5 — Initial Character Isolation

- Automatically opened the full editor for a new QBCore character with no
  saved appearance.
- Required a successful save before closing initial creation.
- Added a dedicated OneSync routing bucket for creation and `/pedmenu`.
- Concealed other players and isolated collision/voice during editing.
- Restored routing bucket, conceal, and voice state after closing.
- Added cleanup for player unload and resource stop.

## 1.0.4 — Editor Layout and Pose

- Centered the character camera and rotation controls.
- Updated the editor pose.
- Fixed clothing-card control overflow.
- Strengthened animation cleanup when closing.

## 1.0.3 — CEF Controls and Freemode Defaults

- Fixed black CEF/backdrop boxes around rotation controls.
- Replaced static and dynamic button icons with inline SVG.
- Fixed movement/task cleanup after closing.
- Added administrator permission compatibility.
- Replaced manual ped selection with QBCore gender-based freemode defaults.
- Updated `/pedmenu` to prepare the correct freemode gender.

## 1.0.2 — Camera Rail and Editor Pose

- Added the camera rail, rotation controls, and animated editor pose.
