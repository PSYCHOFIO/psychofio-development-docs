# Psychofio-Appearance Installation

## Clean installation

1. Back up and completely remove any previous `Psychofio-Appearance` folder.
2. Copy the new `Psychofio-Appearance` folder into `resources/[local]/`.
3. Keep the resource folder name unchanged.
4. Use this start order:

```cfg
ensure oxmysql
ensure qb-core
# When using the default QBCore character flow:
ensure qb-multicharacter
# Start qb-target here when used.
# Start custom clothing stream resources here.
ensure Psychofio-Appearance
```

5. Enable OneSync in txAdmin.
6. Fully restart the server.
7. Confirm this console message:

```text
[Psychofio-Appearance] Started v1.4.3
```

Do not merge files from different releases. Keep only one active character
appearance resource unless the server has an explicitly tested compatibility
layer.

## Database

The resource creates its tables and safe missing columns/indexes at startup.
For a clean manual fallback:

```text
sql/psychofio_appearance.sql
```

For a legacy 1.2.x installation:

1. Back up the resource and database.
2. Install the new resource folder.
3. Start the resource and allow automatic migration to run.
4. If the database account cannot perform the migration, run:

```text
sql/upgrade_1_3_0.sql
```

The legacy upgrade script checks existing indexes and can be run again when
necessary.

## Configuration

Review these editable files before the first start:

```text
shared/config.lua
shared/locales.lua
shared/tattoos.lua
permissions.cfg
```

Keep Discord webhooks and other secrets out of shared/client files.

For optional Discord logs:

```lua
Config.DiscordLogs.enabled = true
```

Set the webhook as a server convar:

```cfg
set psychofio_appearance_discord_webhook "https://discord.com/api/webhooks/..."
```

Never post the webhook, database password, Tebex secret, or server license key
in a support message.

## Administrator permissions

QBCore `admin` and `god` groups are supported directly. When using the optional
administrator permission, define it only in `server.cfg`:

```cfg
add_ace group.admin psychofio.appearance.admin allow
```

Do not execute permission commands from a client console or at resource
runtime.

Set `Config.AllowAdminAce = false` when the optional permission path is not
needed.

## Installation verification

Join the server and run:

```text
/appearancefacecheck
```

The F8 output should include values similar to:

```text
version=1.4.3 build=release-20260728 ... freemode=true conflicts=none
```

Complete these checks on both male and female freemode characters:

1. Change the skin blend using two different parent skin IDs.
2. Move all 20 face sliders in both negative and positive directions.
3. Change beard and eyebrow style, opacity, and color.
4. Test all remaining overlay categories.
5. Change hair, highlights, eye color, clothing, props, and tattoos.
6. Save and close the editor.
7. Reconnect and verify that every value persists.
8. Test `/appearance`, `/pedmenu`, `/barber`, and `/tattoo` using an
   authorized account.
9. Test clothing stores and job wardrobes with a normal player.

## Frozen or blurred screen troubleshooting

If the game remains on a blurred editor background:

- Confirm the active character/multicharacter resource starts before
  Psychofio-Appearance.
- When using QBCore's default flow, confirm `qb-multicharacter` is started.
- Check the client F8 console for NUI errors.
- Check the server console for editor-session or database errors.
- Make sure no second appearance resource is opening or modifying the player.

If `/appearancefacecheck` reports `freemode=false`, use
`mp_m_freemode_01`, `mp_f_freemode_01`, or a correctly configured compatible
freemode model for full face editing.

## Custom clothing packs

Each clothing pack must remain a separate streaming resource. Start it before
Psychofio-Appearance:

```cfg
ensure my-custom-clothes
ensure eup-public
ensure Psychofio-Appearance
```

Do not copy pack files into the appearance resource.

## OneSync

OneSync is required for initial-character and `/pedmenu` routing-bucket
isolation. Enable it through txAdmin settings. Do not add a second conflicting
OneSync setting to `server.cfg` when txAdmin already manages it.

## Cfx.re Asset Escrow entitlement

This resource does not use a separate product license key. The Cfx.re account
that purchased the asset must be correctly associated with the server license
key.

If the console shows `You lack the required entitlement`:

1. Confirm the Cfx.re account used for purchase.
2. Confirm the account that owns `sv_licenseKey`.
3. Verify that the asset appears under owned assets in Cfx Portal.
4. Use a current recommended FXServer artifact.
5. Confirm the archive was not extracted into a nested folder.
6. Confirm the resource folder is named exactly `Psychofio-Appearance`.

## Final acceptance checklist

- Server starts without resource, SQL, or entitlement errors.
- `/appearancefacecheck` reports the expected release and no conflicts.
- Full face editing works on both freemode genders.
- Save/reconnect persistence works.
- Clothing store payment and refund behavior works.
- Job/grade wardrobe restrictions work.
- Custom clothing packs appear in the global drawable list.
- Outfit save, delete, rename, sharing, favorites, folders, and quick slots
  work.
- Ped input rejects invalid and non-ped models.
- Resource restart restores saved appearance without duplicate menus.
