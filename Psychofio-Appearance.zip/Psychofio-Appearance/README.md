# Psychofio-Appearance v1.4.3

Psychofio-Appearance is a complete QBCore appearance, character creation,
clothing store, wardrobe, barber, tattoo, and outfit system backed by oxmysql.

## Highlights

- Stable full-state face engine with head blend, 20 face features, and GTA
  head overlays 0-12.
- Serialized face updates prevent stale NUI responses from moving sliders
  backwards.
- Pending face edits are flushed before save.
- Hair, highlight, eye color, beard, eyebrows, makeup, lipstick, aging, skin
  detail, sun damage, blemishes, freckles, chest hair, and body blemishes.
- Clothing, accessory, tattoo, barber, and full character editor modes.
- Undo/Redo and original-appearance comparison.
- Outfit favorites, folders, live search, share codes, and five quick slots.
- Secure server-issued editor sessions with distance, mode, model, field, and
  catalog validation.
- Change-based store pricing, outfit operation locks, cooldowns, and payment
  refunds when persistence fails.
- Optional Discord audit and security logs.
- Turkish and English in-game interface.
- Validated ped model name, decimal hash, and hexadecimal hash input in
  `/pedmenu`.

## Requirements

- Current FiveM FXServer with OneSync enabled
- QBCore
- oxmysql
- `qb-multicharacter` when using the default QBCore character flow
- Optional `qb-target`

Full face editing requires a compatible freemode model such as
`mp_m_freemode_01` or `mp_f_freemode_01`.

## Installation

Keep the resource folder name exactly:

```text
resources/[local]/Psychofio-Appearance/
```

Recommended `server.cfg` order:

```cfg
ensure oxmysql
ensure qb-core
# When using the default QBCore character flow:
ensure qb-multicharacter
# Start qb-target here when used.
# Start custom clothing stream resources here.
ensure Psychofio-Appearance
```

Tables and safe schema updates are created automatically. For manual setup:

```text
sql/psychofio_appearance.sql
```

For a legacy 1.2.x installation, use `sql/upgrade_1_3_0.sql` only when the
automatic migration cannot complete. Back up the resource and database before
every upgrade.

See `INSTALL.md` for acceptance tests and troubleshooting.

## Administrative commands

The commands below accept QBCore `admin` and `god` groups. The optional
administrator permission configured by the resource can also be used.

```text
/appearance
/appearance [server id]
/pedmenu
/pedmenu [server id]
/barber
/barber [server id]
/tattoo
/tattoo [server id]
```

- `/appearance [id]` opens outfit, clothing, accessory, and settings editing.
  Face, hair, beard, and tattoo editing are not available in this mode.
- `/pedmenu [id]` opens full character editing, including ped model input,
  face, hair, beard, and tattoos.
- `/barber [id]` opens hair, hair color, highlights, and beard editing.
- `/tattoo [id]` opens only the tattoo editor.
- Shops and wardrobes are location-based interactions and still enforce their
  configured job and grade requirements.

To disable the optional administrator permission path, set:

```lua
Config.AllowAdminAce = false
```

## Custom clothing packs

Do not copy clothing packs into this resource. Install each pack as a separate
streaming resource:

```text
resources/[clothing]/my-custom-clothes/
├── fxmanifest.lua
└── stream/
    ├── *.ydd
    ├── *.ytd
    └── *.ymt
```

Example manifest:

```lua
fx_version 'cerulean'
game 'gta5'

files {
    'stream/**/*.ymt'
}

data_file 'SHOP_PED_APPAREL_META_FILE' 'stream/**/*.ymt'
```

Start custom clothing before Psychofio-Appearance:

```cfg
ensure my-custom-clothes
ensure eup-public
ensure Psychofio-Appearance
```

The editor reads the active model's drawable and texture limits through GTA
natives, so GTA, addon, and EUP clothing appear in the normal global drawable
order.

## Adding a clothing store

Add entries to `Config.Shops` in `shared/config.lua`:

```lua
{
    id = 'suburban_del_perro',
    label = { tr = 'Clothing Store', en = 'Clothing Store' },
    coords = vector3(-1194.950, -772.629, 17.325),
    heading = 117.653,
    price = 250,
    interaction = 'key',
    prompt = {
        tr = 'Press ~INPUT_CONTEXT~ to open the clothing menu',
        en = 'Press ~INPUT_CONTEXT~ to open the clothing menu'
    },
    blip = { enabled = true, sprite = 73, color = 47, scale = 0.65 }
}
```

With `interaction = 'key'`, the location uses the E-key prompt even when
`qb-target` is available. Add `marker = false` to disable the ground marker.
Adjust `price` and `Config.CurrencySymbol` for your server economy.

## Adding a job wardrobe

Add entries to `Config.Wardrobes`:

```lua
{
    id = 'police_mrpd',
    label = { tr = 'Police Wardrobe', en = 'Police Wardrobe' },
    coords = vector3(461.3, -998.0, 30.7),
    job = 'police',
    minGrade = 0
}
```

- Wardrobes are free.
- Job and minimum grade are validated.
- A target zone is created when `qb-target` is enabled.
- Otherwise, the optimized marker system is used.

## Integration from another resource

Client menu-opening exports are disabled by default. Grant a short-lived,
server-controlled session from another server resource:

```lua
exports['Psychofio-Appearance']:OpenWardrobeForPlayer(source, {
    label = 'Home Wardrobe'
})
```

For a full or custom-priced flow:

```lua
exports['Psychofio-Appearance']:OpenMenuForPlayer(source, {
    label = 'Custom Clothing Menu',
    mode = 'appearance',
    price = 0,
    defaultTab = 'clothing'
})
```

Prefer `Config.Shops` and `Config.Wardrobes` for fixed locations. Enable
`Config.Security.allowLegacyExternal` only when a legacy client integration
cannot yet be migrated.

## Outfit system

- Save, wear, rename, and delete personal outfits.
- Generate and import sharing codes.
- Sharing codes contain only wearable components and props; they never replace
  face, hair, beard, head blend, makeup, eyes, or tattoos.
- Personal, job, gang, and administrator outfit scopes.
- Maximum of 15 personal outfits per player.
- Favorites, folders, live search, and `/outfit 1-5` quick slots.
- Optional outfit image using a Discord attachment/CDN URL.

Accepted image examples:

```text
https://cdn.discordapp.com/attachments/.../outfit.png
https://media.discordapp.net/attachments/.../outfit.webp
```

When no image is provided, the Psychofio logo is shown.

## Restricted items and job outfits

Lock global drawable values with `Config.RestrictedItems`:

```lua
Config.RestrictedItems = {
    { type = 'component', id = 9, drawable = 12, jobs = { police = 0 } },
    { type = 'prop', id = 0, drawable = 45, adminOnly = true }
}
```

The server validates restrictions again when saving.

Preset job outfits can be added to `Config.JobOutfits`:

```lua
Config.JobOutfits = {
    police = {
        {
            name = 'Patrol',
            minGrade = 0,
            imageUrl = 'https://.../patrol.png',
            appearance = { -- GetAppearance export result }
        }
    }
}
```

## Tattoo catalog

`shared/tattoos.lua` contains torso, left/right arm, left/right leg, head, and
hair-zone entries. The UI filters by zone, supports search, and hides overlays
that do not match the active character model.

Example custom entry:

```lua
Config.Tattoos[#Config.Tattoos + 1] = {
    id = 'custom_back_01',
    label = { tr = 'Custom Back Tattoo', en = 'Custom Back Tattoo' },
    zone = { tr = 'Torso', en = 'Torso' },
    zoneKey = 'ZONE_TORSO',
    camera = 'torso',
    collection = 'my_tattoo_overlays',
    overlayMale = 'MY_TATTOO_BACK_M',
    overlayFemale = 'MY_TATTOO_BACK_F'
}
```

Supported zone keys are `ZONE_TORSO`, `ZONE_LEFT_ARM`, `ZONE_RIGHT_ARM`,
`ZONE_LEFT_LEG`, `ZONE_RIGHT_LEG`, `ZONE_HEAD`, and `ZONE_HAIR`.

## Ped selection

The **Ped Selection** tab in `/pedmenu` accepts a GTA model name, decimal hash,
or hexadecimal hash:

```text
s_m_y_cop_01
1885233650
0x5E3DA4A4
```

The client validates that the model exists and is a ped before applying it.
The server then verifies that the saved model matches the player's active
OneSync ped.

Configuration:

```lua
Config.PedSelection.allowModelInput = true
Config.PedSelection.showPresetModels = false
```

Add optional preset cards with:

```lua
Config.PedModels[#Config.PedModels + 1] = {
    model = 'a_m_y_business_02',
    label = { tr = 'Businessman 2', en = 'Businessman 2' },
    category = 'civilian'
}
```

Non-freemode peds automatically disable incompatible face, beard, hair-color,
and tattoo controls. Enable ped selection during initial creation only when
your server flow requires it.

## Appearance exports

Read and apply appearance data from client scripts:

```lua
local appearance = exports['Psychofio-Appearance']:GetAppearance()
exports['Psychofio-Appearance']:SetAppearance(appearance)
exports['Psychofio-Appearance']:ConvertQbClothing(qbSkinData)
```

Open menus from server scripts:

```lua
exports['Psychofio-Appearance']:OpenMenuForPlayer(source, options)
exports['Psychofio-Appearance']:OpenWardrobeForPlayer(source, options)
```

## Face engine

- One authoritative face draft drives head blend, 20 feature morphs, and all
  supported overlays.
- Head blend is applied only when its values change.
- Face-feature and overlay values are explicitly converted to Lua floats.
- A latest-state queue prevents old requests from overwriting new edits.
- Save waits for the queue to finish.
- Beard style `-1` represents no beard; style `0` remains a valid beard.
- Beard opacity and color are preserved when changing styles.
- Component and prop limits are read from the active model.

## Character creation and isolation

When a new QBCore character has no saved Psychofio appearance, the full editor
opens after `QBCore:Client:OnPlayerLoaded`.

- Initial creation cannot close before a successful save.
- Initial creation and `/pedmenu` use a temporary OneSync routing bucket.
- Population is disabled in the isolated bucket.
- Other players are concealed and their voice volume is overridden locally.
- The previous routing bucket and voice state are restored when the editor
  closes.
- A new character starts from a clean freemode ped so data from the previous
  character cannot leak.

Settings are under `Config.CharacterCreation`.

## Editor modes

- `appearance`: clothing, props, outfits, and settings.
- `pedmenu`: full face, head blend, hair, beard, makeup, tattoos, and ped model.
- `barber`: hair, hair colors, highlights, and beard.
- `tattoo`: tattoos only.

The camera rail switches between head, torso, legs, and feet. Selecting the
active camera again returns to the main full-body view. Rotation controls use
CEF-compatible inline SVG icons.

## Performance

- No NUI or camera loop runs while the editor is closed.
- Distant marker checks sleep for 1500 ms.
- Marker scanning is skipped when `qb-target` is active.
- Drawable and texture limits are cached per model, slot, and drawable.
- Tattoo catalogs are cached by ped model and language.
- NUI changes are merged through a short throttle.
- Saved appearance is applied once after player load and resource restart.

Performance options are under `Config.Performance`.

## Asset Escrow and distribution

- Lua 5.4 is enabled.
- Core client/server Lua files are protected by Cfx.re Asset Escrow.
- Configuration, locales, tattoos, permissions, SQL, and documentation remain
  customer-editable.
- There is no separate IP lock, Discord key, or manual serial.
- The purchasing Cfx.re account must be entitled for the server license key.
- Keep the folder name `Psychofio-Appearance`.

Read `LICENSE.md`, `SUPPORT_POLICY.md`, `START_HERE.md`, and
`THIRD_PARTY_NOTICES.md` before distribution or installation.
