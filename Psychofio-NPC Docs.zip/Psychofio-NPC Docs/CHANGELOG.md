# Psychofio-NPC Changelog

## v3.5.2

- Removed the legacy server authorization method, its settings, and runtime
  checks. The `auto` mode now resolves only QBCore or ESX framework
  permissions.
- Limited customer runtime archives to code, configuration, SQL, and runtime
  assets.
- Moved Markdown documentation into a separate GitHub-ready documentation
  bundle.

## v3.5.1

- Assigned automatic file discovery and runtime export registrations separate
  source identities, preventing a delayed scan from deleting custom
  animations registered by the same resource.
- Fixed runtime registry persistence that could incorrectly reactivate failed
  or conflicting export registrations after a reload.
- Removed the placeholder commercial-license sentence and internal development
  document from the customer distribution.
- Excluded test harnesses and internal test reports from the sales archive.

## v3.5.0

- Removed the need to copy custom animations into the NPC configuration.
- Added automatic scanning of common animation-list paths in running
  resources.
- Added discovery of Lua and JSON files declared by resource manifests when
  their paths contain animation, emote, dance, or pose markers.
- Added automatic imports for animation resources started after
  Psychofio-NPC.
- Unified NUI, AnimPos instructions, client/server notifications, command help,
  and console status text under a single `Config.Language` setting.
- Completed English coverage validation for user-facing and console messages.
- Made no changes to Psychofio-Appearance source files.

## v3.4.0

- Added configurable `tr` and `en` language support for notifications and menu
  text.
- Completed localization for placement NUI, selection NUI, key labels, and the
  AnimPos help panel.
- Added `Config.AnimationDiscovery.ResourceFiles` for non-standard animation
  file layouts.
- Added direct custom YCD dictionary/clip registration through
  `Config.CustomAnimations`.
- Extended automatic Lua discovery to support positional RPEmotes/DPEmotes
  tables and named fields such as `dict/clip` and
  `dictionary/animation`.
- Preserved loop/movement options, `Prop`, `PropBone`, `PropPlacement`,
  `SecondProp`, and second-prop placement data.
- Added numeric model-hash support for animation props and cleanup of local
  prop objects when the NPC leaves scope.
- Added dedicated tests for localization, custom-resource discovery, and
  two-prop animation flows.
- Made no changes to Psychofio-Appearance source files.

## v3.3.7

- Restored the persistent `npcId` in management payloads after selection. It
  is sent with the NetID, model, and coordinates.
- Rebuilt the shared `validateSelectedEntity` gate around the runtime and SQL
  identity registries.
- Allowed management actions to continue when the server ped handle is
  temporarily outside OneSync scope, after validating permission, model,
  stored coordinates, player distance, and routing bucket.
- Moved tag, look, turn, and AnimPos persistence to the server and broadcast
  the verified identity payload to clients that can see the entity.
- Allowed animation dispatch through a verified selected NetID when the server
  ped handle is unavailable.
- Added mocked runtime coverage for tag, look, turn, AnimPos, and animation
  handlers with an unavailable server entity handle.

## v3.3.6

- Removed the strict server-entity-handle requirement introduced in v3.3.5.
- Merged runtime NPC data with the lightweight SQL identity/position registry
  for `/npcselect`, `/npcdelete`, and `/npcclear`.
- Added persistent-ID and stored-coordinate fallback during OneSync scope or
  ownership transitions.
- Cached the persistent identity after creation even when the entity had not
  yet returned to client scope.
- Broadcast deletion using an identity payload containing ID, model, NetID,
  and coordinates so clients can resolve the correct NPC if the server handle
  is unavailable.
- Added mocked runtime coverage for selection, deletion, and clearing with a
  deliberately unavailable server entity handle.

## v3.3.5

- Resolved `/npcdelete` and `/npcclear` targets from the server-managed NPC
  registry instead of trusting a client state bag.
- Verified that the SQL row was deleted before removing the world entity or
  runtime entry. The NPC remains in place and an explicit error is returned if
  SQL deletion fails.
- Prevented clients from deleting an NPC locally or reporting success before
  server confirmation.
- Changed plain `/npcselect` to select the nearest server-managed NPC by
  default and retained crosshair selection as `/npcselect aim`.
- Set `ControlMode = "permission"` as the default so authorized admins can
  control managed NPCs; the optional `creator` mode remains available.

## v3.3.4

- Prevented `/npcselect` from rejecting a newly created network NPC while its
  NPC ID or owner state bag was still replicating.
- Increased client identity-resolution time to tolerate network latency.
- Added the known persistent NPC ID as a guarded server resolver hint to avoid
  NetID/state-bag races.
- Ensured a rate-limit rejection returns a response instead of causing a client
  timeout.
- Required persistent ID, model, and coordinate agreement before accepting a
  stale or reused NetID.

## v3.3.3

- Made the Psychofio-Appearance integration one-way and read-only. NPC reads
  only the `GetAppearance` and `IsFreemodePed` exports.
- Applied clothing components before the face engine so component 0 no longer
  clears head blend, face features, beard, or eyebrow overlays.
- Completed missing appearance-overlay color types according to GTA overlay
  IDs.
- Replaced silent component/prop-only fallback with a clear placement error
  when required Appearance data is missing.
- Validated stale or reused NetIDs against model, NPC ID, and coordinates.
- Applied appearance state bags only to NPCs carrying a persistent
  `psychofioNpc:id`.
- Added `/psynpcappearancecheck` for connection and appearance-schema
  diagnostics.

## v3.3.2

- Moved all state-bag keys into the `psychofioNpc:*` namespace.
- Added central player-ped guards to every appearance, weapon, look, position,
  heading, animation, collision, identity, and hard-delete client path.
- Prevented the server registration validator from accepting a player ped as
  an NPC.
- Prevented stale or reused NetID resolution and deletion paths from touching
  player peds.
- Stopped missing `faceFeatures` values from being written as `-1`.
- Preserved existing hair, eye color, and tattoo values when partial
  appearance data omits those fields.
- Fixed a state-bag conflict that could later reset a player's face.

## v3.3.1

- Removed the client owner-state-bag dependency from NPC selection.
- Moved final selection and ownership validation to the server.
- Bound ownership to the creator's current server ID.
- Fixed rejection caused by a license/identifier mismatch for an NPC belonging
  to the same session owner.
- Fixed selection of a creator's NPC during state-bag or client-cache delay.

## v3.3.0 — Session Ownership

- Bound every created NPC to the creator's current FiveM server ID and license
  identifier.
- Restricted name, look, heading, animation, AnimPos, copy, and deletion
  actions according to the configured ownership control mode.
- Removed a disconnected creator's NPCs from both the world and the
  `psychofio_npcs` table.
- Restored NPCs after a resource restart only when their owner is still
  connected in the same session.
- Removed offline-owner and legacy unowned SQL rows during startup.
- Added the `owner_source` and `owner_identifier` database columns.
- Added the `idx_owner_source` index for owner cleanup queries.

## v3.2.4 — Interactive NPC Selection

- Integrated the crosshair-based selection workflow into Psychofio-NPC.
- Added a red outline, marker, and camera trace for managed NPCs under the
  crosshair.
- Added Enter/left-click confirmation and Backspace/Escape cancellation.
- Retained `/npcselect nearest` as an explicit server-nearest selection path.
- Added localized selection overlay text.
- Preserved server-side persistent identity validation before committing a
  selection.

## v3.2.3 — Restart Duplicate and Selection Hotfix

- Prevented unconditional SQL NPC spawning after a resource restart.
- Adopted matching existing entities before spawning missing NPCs.
- Removed duplicate ghost entities by persistent ID and NetID without deleting
  their valid SQL record.
- Resolved plain `/npcselect` through the server-managed persistent registry
  instead of relying on client raycast timing.
- Added `Config.Selection.SelectDistance` and
  `Config.RestartReconciliation`.
- Added `/npcdedupe` for manual duplicate cleanup without SQL deletion.

## v3.2.2 — Nearby NPC Selection Fix

- Prioritized the nearest managed NPC within the configured close-selection
  radius.
- Added camera-center fallback for NPCs outside that radius.
- Added one server synchronization retry when the client has not yet received
  the entity identity.
- Added `Config.Selection.NearPriorityDistance` and
  `Config.Selection.SyncRetryDelay`.

## v3.2.1 — Locale, Command, and Position Lock Fix

- Fixed the `shared/locales.lua` load-order error.
- Ensured the `PsychofioNPC` table exists before the locale module runs.
- Added a safe notification fallback for a missing or failing translation
  function.
- Restored `npcselect`, `npcanim`, and `npcanimpos` flows interrupted by the
  locale error.
- Prevented periodic collision/freeze refreshes from breaking the AnimPos
  editor.
- Anchored managed NPCs to their placed position.
- Reduced animation drift and physics-based displacement.
- Validated both Turkish and English locale loading at runtime.

## v3.1.2 — Permission Compatibility Fix

- Added the `auto` framework permission mode.
- Added QBCore `god/admin` and ESX `superadmin/admin` support.
- Added `/psynpcperm` to report the resolved permission source and denial
  reason.
- Improved permission-denied notifications with a diagnostic hint.
- Preserved compatibility with `Config.UsePermissions`.

## v3.1.1 — Security and Tebex Release

- Added short-lived, single-use, server-controlled NPC placement sessions.
- Validated entity ownership, real coordinates, heading, model, and routing
  bucket during registration.
- Removed trust in client coordinates from nearby deletion and cleanup.
- Cross-validated NetID, state-bag identity, database row, model, and real
  entity position.
- Disabled deletion of unmanaged ambient NPCs by default.
- Added server rate limits for creation, selection, editing, animation,
  synchronization, and deletion events.
- Added a concurrency lock around the global NPC limit.
- Tracked duplicate request IDs per player.
- Accepted animation results only from approved entity owners or request
  clients.
- Added guarded SQL queries and updates.
- Replaced the legacy AnimPos adaptation with an independently written native
  position editor.
- Added secure server exports and optional Discord audit logs.
- Added Asset Escrow configuration, support terms, and installation
  documentation.
- Fixed stale version notifications and documentation inconsistencies.
