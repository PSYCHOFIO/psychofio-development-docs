# START HERE — Psychofio-NPC v3.5.2

## 1. Requirements

- FiveM OneSync
- `oxmysql`
- `Psychofio-Appearance`
- A supported QBCore or ESX installation when framework permissions are enabled

## 2. Installation

1. Keep the resource folder name as `Psychofio-NPC`.
2. Confirm that OneSync, `oxmysql`, and `Psychofio-Appearance` are running.
3. Import `sql/psychofio_npcs.sql`.
4. Review `config.lua` and the server-only options in `server_config.lua`.
5. Start the resource:

```cfg
ensure oxmysql
ensure Psychofio-Appearance
ensure Psychofio-NPC
```

## 3. Permissions

The default `auto` mode accepts QBCore `admin`/`god` or ESX
`admin`/`superadmin`, depending on the active framework. Set
`Config.UsePermissions = false` only when framework authorization is not
required.

Run `/psynpcperm` in game to see the resolved framework and permission result.

## 4. Language

Set `Config.Language` to `en` or `tr`. This setting controls notifications,
menus, AnimPos instructions, command help, and server/F8 status messages.

## 5. First acceptance test

1. Run `/psynpcappearancecheck` and confirm the read-only Appearance connection.
2. Create and place an NPC with `/psynpc`.
3. Select it with `/npcselect`.
4. Test its name, animation, heading, look target, and AnimPos controls.
5. Delete it with `/npcdelete` and confirm that its SQL row is removed.
6. Restart the resource and verify that valid managed NPCs reconcile correctly.
7. Disconnect the creator and verify that their session-owned NPCs are removed
   from both the world and SQL.

## 6. NPC selection

Use `/npcselect` to select the nearest managed NPC through the server registry.
For crosshair selection, use `/npcselect aim`, then press Enter or left click.
Backspace or Escape cancels aim mode.

## 7. Session ownership

Each NPC stores the creator's current server ID for disconnect cleanup. With
the default `Config.Ownership.ControlMode = "permission"`, authorized admins
can control all managed NPCs. Set the mode to `creator` to restrict control to
the creator.

The database migration is automatic. Run `sql/upgrade_3_3_0.sql` manually only
when the database account cannot use `ALTER TABLE`. Back up the
`psychofio_npcs` table before upgrading from an older release.

## 8. Entitlement errors

Read `ASSET_ESCROW.md` if the server reports a missing entitlement.

For installation details, commands, and integration examples, continue with
`README_EN.md` and `ANIMATION_INTEGRATION_EN.md`.
